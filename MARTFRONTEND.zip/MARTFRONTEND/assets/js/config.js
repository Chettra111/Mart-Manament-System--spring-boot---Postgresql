window.MMS_CONFIG = {
  API_BASE_URL: localStorage.getItem("mms_api_base_url") || "http://localhost:8080",
  TOKEN_KEY: "mms_token",
  USER_KEY: "mms_user",
  CURRENCY: "USD"
};
