(async function () {
  let sales = [], customers = [], employees = [], products = [];
  let seq = 0;
  const user = auth.currentUser();
  const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById("saleModal"));

  document.getElementById("newSaleBtn").addEventListener("click", openCreate);
  document.getElementById("addSaleItem").addEventListener("click", () => addItem());
  document.getElementById("saleSearch").addEventListener("input", render);
  document.getElementById("saleForm").addEventListener("submit", saveSale);

  async function load() {
    ui.showLoading(true);
    try {
      const requests = [
        api("/api/sales"),
        api("/api/customers"),
        api("/api/products")
      ];

      // Employees endpoint is ADMIN/MANAGER only in current backend.
      // Cashier can type an employee ID if the list cannot be loaded.
      let employeePromise = api("/api/employees").catch(() => []);
      [sales, customers, products, employees] = await Promise.all([...requests, employeePromise]);
      render();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  function render() {
    const q = document.getElementById("saleSearch").value.trim().toLowerCase();
    const data = sales.filter(x =>
      !q ||
      String(x.invoiceNumber || "").toLowerCase().includes(q) ||
      String(x.customerName || "").toLowerCase().includes(q)
    );

    document.getElementById("saleTableBody").innerHTML = data.length
      ? data.map(x => `
        <tr>
          <td>${x.id}</td>
          <td class="fw-semibold">${ui.escapeHtml(x.invoiceNumber)}</td>
          <td>${ui.dateTime(x.saleDate)}</td>
          <td>${ui.escapeHtml(x.customerName || "Walk-in")}</td>
          <td>${ui.escapeHtml(x.employeeName)}</td>
          <td>${ui.badge(x.status)}</td>
          <td class="fw-semibold">${ui.money(x.total)}</td>
          <td>${ui.money(x.amountPaid)}</td>
          <td class="text-end">
            <button class="btn btn-sm btn-light btn-icon me-1" onclick="salePage.view(${x.id})"><i class="bi bi-eye"></i></button>
            ${["ADMIN","MANAGER"].includes(user.role) && x.status === "COMPLETED"
              ? `<button class="btn btn-sm btn-light text-warning btn-icon" onclick="salePage.cancel(${x.id})"><i class="bi bi-x-circle"></i></button>` : ""}
          </td>
        </tr>
      `).join("")
      : `<tr><td colspan="9"><div class="empty-state"><i class="bi bi-receipt"></i>No sales found.</div></td></tr>`;
  }

  function openCreate() {
    document.getElementById("saleCustomer").innerHTML =
      `<option value="">Walk-in Customer</option>` +
      customers.filter(x => x.active).map(x => `<option value="${x.id}">${ui.escapeHtml(x.name)}</option>`).join("");

    const employeeSelect = document.getElementById("saleEmployee");
    if (employees.length) {
      employeeSelect.innerHTML = `<option value="">Select employee...</option>` +
        employees.filter(x => x.status === "ACTIVE").map(x => `<option value="${x.id}">${ui.escapeHtml(x.fullName)}</option>`).join("");
    } else {
      employeeSelect.innerHTML = `<option value="">Enter employee ID below is unavailable</option>`;
      const id = prompt("Employee list is restricted for this role. Enter your Employee ID:");
      if (id) employeeSelect.innerHTML = `<option value="${Number(id)}" selected>Employee ID ${Number(id)}</option>`;
    }

    document.getElementById("saleDate").value = "";
    document.getElementById("saleDiscount").value = "0";
    document.getElementById("saleTax").value = "0";
    document.getElementById("saleAmountPaid").value = "0";
    document.getElementById("saleNotes").value = "";
    document.getElementById("saleItems").innerHTML = "";
    seq = 0;
    addItem();
    modal.show();
  }

  function addItem() {
    const wrap = document.createElement("div");
    wrap.className = "transaction-item-row";
    wrap.dataset.row = ++seq;
    wrap.innerHTML = `
      <div class="product-field">
        <label class="form-label">Product</label>
        <select class="form-select item-product" required>
          <option value="">Select product...</option>
          ${products.filter(x => x.active && x.stockQuantity > 0).map(x => `
            <option value="${x.id}" data-price="${x.sellingPrice}" data-stock="${x.stockQuantity}">
              ${ui.escapeHtml(x.name)} (${ui.escapeHtml(x.barcode)}) — Stock ${x.stockQuantity}
            </option>
          `).join("")}
        </select>
      </div>
      <div>
        <label class="form-label">Qty</label>
        <input type="number" min="1" step="1" value="1" class="form-control item-qty" required>
      </div>
      <div>
        <label class="form-label">Unit Price</label>
        <input type="number" min="0.01" step="0.01" class="form-control item-price" required>
      </div>
      <div class="remove-field">
        <button type="button" class="btn btn-outline-danger btn-icon w-100 remove-item"><i class="bi bi-trash"></i></button>
      </div>
    `;
    document.getElementById("saleItems").appendChild(wrap);

    wrap.querySelector(".item-product").addEventListener("change", e => {
      const opt = e.target.selectedOptions[0];
      wrap.querySelector(".item-price").value = opt?.dataset.price || "";
      wrap.querySelector(".item-qty").max = opt?.dataset.stock || "";
      updateTotal();
    });
    wrap.querySelector(".item-qty").addEventListener("input", updateTotal);
    wrap.querySelector(".item-price").addEventListener("input", updateTotal);
    wrap.querySelector(".remove-item").addEventListener("click", () => {
      wrap.remove();
      updateTotal();
    });
    updateTotal();
  }

  function getItems() {
    return [...document.querySelectorAll("#saleItems .transaction-item-row")].map(row => ({
      productId: Number(row.querySelector(".item-product").value),
      quantity: Number(row.querySelector(".item-qty").value),
      unitPrice: Number(row.querySelector(".item-price").value)
    })).filter(x => x.productId);
  }

  function calculateTotal() {
    const subtotal = getItems().reduce((s, x) => s + x.quantity * x.unitPrice, 0);
    return subtotal - Number(document.getElementById("saleDiscount").value || 0)
      + Number(document.getElementById("saleTax").value || 0);
  }

  function updateTotal() {
    const total = calculateTotal();
    const paid = Number(document.getElementById("saleAmountPaid").value || 0);
    document.getElementById("saleEstimatedTotal").textContent = ui.money(total);
    document.getElementById("saleEstimatedChange").textContent = ui.money(Math.max(0, paid - total));
  }

  ["saleDiscount","saleTax","saleAmountPaid"].forEach(id =>
    document.getElementById(id).addEventListener("input", updateTotal)
  );

  async function saveSale(e) {
    e.preventDefault();
    const items = getItems();
    if (!items.length) {
      ui.toast("Add at least one sale item.", "warning");
      return;
    }

    const total = calculateTotal();
    const paid = Number(document.getElementById("saleAmountPaid").value || 0);
    if (paid < total) {
      ui.toast(`Amount paid must be at least ${ui.money(total)}.`, "warning");
      return;
    }

    const customerVal = document.getElementById("saleCustomer").value;
    const date = document.getElementById("saleDate").value;

    const payload = {
      customerId: customerVal ? Number(customerVal) : null,
      employeeId: Number(document.getElementById("saleEmployee").value),
      saleDate: date || null,
      discount: Number(document.getElementById("saleDiscount").value || 0),
      tax: Number(document.getElementById("saleTax").value || 0),
      amountPaid: paid,
      notes: document.getElementById("saleNotes").value || null,
      items
    };

    ui.showLoading(true);
    try {
      await api("/api/sales", { method: "POST", body: payload });
      modal.hide();
      ui.toast("Sale completed. Product stock reduced.");
      await load();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  async function view(id) {
    const x = await api(`/api/sales/${id}`);
    document.getElementById("saleDetailBody").innerHTML = `
      <div class="row g-2 mb-3">
        <div class="col-md-6"><strong>Invoice:</strong> ${ui.escapeHtml(x.invoiceNumber)}</div>
        <div class="col-md-6"><strong>Status:</strong> ${ui.badge(x.status)}</div>
        <div class="col-md-6"><strong>Customer:</strong> ${ui.escapeHtml(x.customerName || "Walk-in")}</div>
        <div class="col-md-6"><strong>Employee:</strong> ${ui.escapeHtml(x.employeeName)}</div>
      </div>
      <div class="table-responsive">
        <table class="table table-sm">
          <thead><tr><th>Product</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead>
          <tbody>${x.items.map(i => `<tr><td>${ui.escapeHtml(i.productName)}</td><td>${i.quantity}</td><td>${ui.money(i.unitPrice)}</td><td>${ui.money(i.lineTotal)}</td></tr>`).join("")}</tbody>
        </table>
      </div>
      <div class="text-end">
        <div>Total: <strong>${ui.money(x.total)}</strong></div>
        <div>Paid: ${ui.money(x.amountPaid)}</div>
        <div>Change: ${ui.money(x.changeAmount)}</div>
      </div>
    `;
    bootstrap.Modal.getOrCreateInstance(document.getElementById("saleDetailModal")).show();
  }

  async function cancel(id) {
    if (!await ui.confirmAction("Cancel this sale? Sold stock will be restored.")) return;
    ui.showLoading(true);
    try {
      await api(`/api/sales/${id}/cancel`, { method: "POST" });
      ui.toast("Sale cancelled.");
      await load();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  window.salePage = { view, cancel };
  await load();
})();
