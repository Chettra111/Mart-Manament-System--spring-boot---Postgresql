(function () {
  const cfg = window.MMS_CONFIG;

  async function api(path, options = {}) {
    const {
      method = "GET",
      body,
      headers = {},
      publicRequest = false,
      raw = false
    } = options;

    const finalHeaders = { ...headers };
    if (body !== undefined && body !== null && !finalHeaders["Content-Type"]) {
      finalHeaders["Content-Type"] = "application/json";
    }

    if (!publicRequest) {
      const token = localStorage.getItem(cfg.TOKEN_KEY);
      if (token) {
        finalHeaders.Authorization = `Bearer ${token}`;
      }
    }

    let response;
    try {
      response = await fetch(`${cfg.API_BASE_URL}${path}`, {
        method,
        headers: finalHeaders,
        body: body === undefined || body === null
          ? undefined
          : (typeof body === "string" ? body : JSON.stringify(body))
      });
    } catch (err) {
      throw new Error(`Cannot connect to API Gateway (${cfg.API_BASE_URL}). Make sure port 8080 is running.`);
    }

    if (response.status === 401 && !publicRequest) {
      localStorage.removeItem(cfg.TOKEN_KEY);
      localStorage.removeItem(cfg.USER_KEY);
      if (!location.pathname.endsWith("login.html")) {
        location.href = "login.html";
      }
    }

    if (!response.ok) {
      let data = null;
      try { data = await response.json(); } catch (_) {}
      const validation = data?.validationErrors
        ? Object.values(data.validationErrors).join(", ")
        : "";
      const message =
        validation ||
        data?.message ||
        data?.error ||
        `${response.status} ${response.statusText}`;
      const error = new Error(message);
      error.status = response.status;
      error.data = data;
      throw error;
    }

    if (raw) return response;
    if (response.status === 204) return null;

    const contentType = response.headers.get("content-type") || "";
    return contentType.includes("application/json")
      ? response.json()
      : response.text();
  }

  window.api = api;
})();
