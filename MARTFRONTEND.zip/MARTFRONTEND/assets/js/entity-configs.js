window.ENTITY_CONFIGS = {
  categories: {
    title: "Category",
    endpoint: "/api/categories",
    createRoles: ["ADMIN","MANAGER","STOCK_KEEPER"],
    editRoles: ["ADMIN","MANAGER","STOCK_KEEPER"],
    deleteRoles: ["ADMIN","MANAGER"],
    fields: [
      { name: "name", label: "Name", required: true },
      { name: "description", label: "Description", type: "textarea", col: 12 },
      { name: "active", label: "Active", type: "checkbox", default: true }
    ],
    columns: [
      ["id","ID"], ["name","Name"], ["description","Description"],
      ["active","Status","boolean"]
    ]
  },

  products: {
    title: "Product",
    endpoint: "/api/products",
    createRoles: ["ADMIN","MANAGER","STOCK_KEEPER"],
    editRoles: ["ADMIN","MANAGER","STOCK_KEEPER"],
    deleteRoles: ["ADMIN","MANAGER"],
    fields: [
      { name: "barcode", label: "Barcode", required: true },
      { name: "name", label: "Product Name", required: true },
      { name: "purchasePrice", label: "Purchase Price", type: "number", step: "0.01", required: true },
      { name: "sellingPrice", label: "Selling Price", type: "number", step: "0.01", required: true },
      { name: "stockQuantity", label: "Stock Quantity", type: "number", step: "1", required: true },
      { name: "minimumStock", label: "Minimum Stock", type: "number", step: "1", required: true },
      { name: "categoryId", label: "Category", type: "select-api", required: true, endpoint: "/api/categories", valueKey: "id", textKey: "name" },
      { name: "active", label: "Active", type: "checkbox", default: true }
    ],
    columns: [
      ["id","ID"], ["barcode","Barcode"], ["name","Name"],
      ["categoryName","Category"], ["purchasePrice","Purchase","money"],
      ["sellingPrice","Selling","money"], ["stockQuantity","Stock"],
      ["lowStock","Low Stock","boolean-warning"], ["active","Status","boolean"]
    ]
  },

  suppliers: {
    title: "Supplier",
    endpoint: "/api/suppliers",
    createRoles: ["ADMIN","MANAGER","STOCK_KEEPER"],
    editRoles: ["ADMIN","MANAGER","STOCK_KEEPER"],
    deleteRoles: ["ADMIN","MANAGER"],
    fields: [
      { name: "code", label: "Code", required: true },
      { name: "name", label: "Name", required: true },
      { name: "phone", label: "Phone" },
      { name: "email", label: "Email", type: "email" },
      { name: "address", label: "Address", type: "textarea", col: 12 },
      { name: "active", label: "Active", type: "checkbox", default: true }
    ],
    columns: [
      ["id","ID"], ["code","Code"], ["name","Name"], ["phone","Phone"],
      ["email","Email"], ["active","Status","boolean"]
    ]
  },

  customers: {
    title: "Customer",
    endpoint: "/api/customers",
    createRoles: ["ADMIN","MANAGER","CASHIER"],
    editRoles: ["ADMIN","MANAGER","CASHIER"],
    deleteRoles: ["ADMIN","MANAGER"],
    fields: [
      { name: "code", label: "Code", required: true },
      { name: "name", label: "Name", required: true },
      { name: "phone", label: "Phone" },
      { name: "email", label: "Email", type: "email" },
      { name: "address", label: "Address", type: "textarea", col: 12 },
      { name: "active", label: "Active", type: "checkbox", default: true }
    ],
    columns: [
      ["id","ID"], ["code","Code"], ["name","Name"], ["phone","Phone"],
      ["email","Email"], ["active","Status","boolean"]
    ]
  },

  employees: {
    title: "Employee",
    endpoint: "/api/employees",
    createRoles: ["ADMIN","MANAGER"],
    editRoles: ["ADMIN","MANAGER"],
    deleteRoles: ["ADMIN","MANAGER"],
    fields: [
      { name: "code", label: "Employee Code", required: true },
      { name: "firstName", label: "First Name", required: true },
      { name: "lastName", label: "Last Name", required: true },
      { name: "gender", label: "Gender", type: "select", options: ["MALE","FEMALE","OTHER"] },
      { name: "phone", label: "Phone" },
      { name: "email", label: "Email", type: "email" },
      { name: "address", label: "Address", type: "textarea", col: 12 },
      { name: "position", label: "Position", type: "select", required: true, options: ["MANAGER","CASHIER","STOCK_KEEPER","PURCHASING_STAFF","OTHER"] },
      { name: "salary", label: "Salary", type: "number", step: "0.01", required: true },
      { name: "hireDate", label: "Hire Date", type: "date", required: true },
      { name: "status", label: "Status", type: "select", required: true, options: ["ACTIVE","INACTIVE","RESIGNED"] },
      { name: "appUserId", label: "App User ID (optional)", type: "number", step: "1" }
    ],
    columns: [
      ["id","ID"], ["code","Code"], ["fullName","Name"], ["position","Position","badge"],
      ["salary","Salary","money"], ["hireDate","Hire Date","date"], ["status","Status","badge"]
    ]
  },

  users: {
    title: "User",
    endpoint: "/api/users",
    createRoles: ["ADMIN"],
    editRoles: ["ADMIN"],
    deleteRoles: ["ADMIN"],
    createFields: [
      { name: "username", label: "Username", required: true },
      { name: "email", label: "Email", type: "email", required: true },
      { name: "password", label: "Password", type: "password", required: true },
      { name: "role", label: "Role", type: "select", required: true, options: ["ADMIN","MANAGER","CASHIER","STOCK_KEEPER"] }
    ],
    editFields: [
      { name: "email", label: "Email", type: "email", required: true },
      { name: "role", label: "Role", type: "select", required: true, options: ["ADMIN","MANAGER","CASHIER","STOCK_KEEPER"] },
      { name: "enabled", label: "Enabled", type: "checkbox", default: true }
    ],
    columns: [
      ["id","ID"], ["username","Username"], ["email","Email"], ["role","Role","badge"],
      ["enabled","Status","boolean"], ["createdAt","Created","datetime"]
    ]
  }
};
