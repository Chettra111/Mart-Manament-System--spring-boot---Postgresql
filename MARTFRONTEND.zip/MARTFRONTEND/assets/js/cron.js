(async function () {
  document.getElementById("dailyReportDate").value = new Date().toISOString().slice(0,10);
  document.getElementById("refreshJobs").addEventListener("click", loadJobs);

  document.querySelectorAll("[data-job]").forEach(btn =>
    btn.addEventListener("click", () => runJob(btn.dataset.job))
  );

  async function loadConfig() {
    const c = await api("/api/cron/config");
    document.getElementById("cronConfigCards").innerHTML = `
      <div class="col-sm-6 col-xl-3"><div class="stat-card"><div class="stat-icon icon-green"><i class="bi bi-power"></i></div><div class="stat-value fs-4">${c.enabled ? "Enabled" : "Disabled"}</div><div class="stat-label">Scheduler</div></div></div>
      <div class="col-sm-6 col-xl-3"><div class="stat-card"><div class="stat-icon icon-blue"><i class="bi bi-globe2"></i></div><div class="stat-value fs-5">${ui.escapeHtml(c.zone)}</div><div class="stat-label">Timezone</div></div></div>
      <div class="col-sm-6 col-xl-3"><div class="stat-card"><div class="stat-icon icon-purple"><i class="bi bi-heart-pulse"></i></div><div class="stat-value fs-5">${ui.escapeHtml(c.healthCheckCron)}</div><div class="stat-label">Health Check CRON</div></div></div>
      <div class="col-sm-6 col-xl-3"><div class="stat-card"><div class="stat-icon icon-orange"><i class="bi bi-archive"></i></div><div class="stat-value fs-4">${ui.number(c.historyRetentionDays)} days</div><div class="stat-label">History Retention</div></div></div>
    `;
  }

  async function loadJobs() {
    ui.showLoading(true);
    try {
      const jobs = await api("/api/cron/jobs");
      document.getElementById("cronJobsBody").innerHTML = jobs.length
        ? jobs.map(x => `
          <tr>
            <td>${x.id}</td>
            <td class="fw-semibold">${ui.escapeHtml(x.jobName)}</td>
            <td>${ui.badge(x.status)}</td>
            <td>${ui.badge(x.triggerType)}</td>
            <td>${ui.dateTime(x.startedAt)}</td>
            <td>${x.httpStatus ?? "-"}</td>
            <td>${ui.escapeHtml(x.triggeredBy || "-")}</td>
            <td style="max-width:280px" class="text-truncate">${ui.escapeHtml(x.message || "-")}</td>
          </tr>
        `).join("")
        : `<tr><td colspan="8"><div class="empty-state"><i class="bi bi-clock-history"></i>No job history.</div></td></tr>`;
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  async function runJob(type) {
    let path = "";
    if (type === "daily") {
      const date = document.getElementById("dailyReportDate").value;
      path = `/api/cron/jobs/daily-report${date ? `?date=${date}` : ""}`;
    }
    if (type === "low") path = "/api/cron/jobs/low-stock";
    if (type === "health") path = "/api/cron/jobs/health-check";
    if (type === "cleanup") path = "/api/cron/jobs/cleanup?retentionDays=30";

    ui.showLoading(true);
    try {
      const result = await api(path, { method: "POST" });
      ui.toast(`${result.jobName}: ${result.status}`);
      await loadJobs();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  ui.showLoading(true);
  try {
    await loadConfig();
    await loadJobs();
  } catch (err) {
    ui.toast(err.message, "danger");
  } finally {
    ui.showLoading(false);
  }
})();
