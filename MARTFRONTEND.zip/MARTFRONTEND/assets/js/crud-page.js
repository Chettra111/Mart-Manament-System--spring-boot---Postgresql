(async function () {
  const entity = document.body.dataset.entity;
  const config = window.ENTITY_CONFIGS[entity];
  if (!config) return;

  const user = auth.currentUser();
  let rows = [];
  let modal;

  const canCreate = config.createRoles?.includes(user.role);
  const canEdit = config.editRoles?.includes(user.role);
  const canDelete = config.deleteRoles?.includes(user.role);

  document.getElementById("pageActions").innerHTML = canCreate
    ? `<button class="btn btn-primary" id="addBtn"><i class="bi bi-plus-lg me-1"></i>Add ${config.title}</button>`
    : "";

  const actionHeader = (canEdit || canDelete) ? `<th class="text-end">Actions</th>` : "";
  document.getElementById("entityTableHead").innerHTML =
    `<tr>${config.columns.map(c => `<th>${ui.escapeHtml(c[1])}</th>`).join("")}${actionHeader}</tr>`;

  document.getElementById("addBtn")?.addEventListener("click", () => openModal());

  document.getElementById("entitySearch").addEventListener("input", render);

  async function load() {
    ui.showLoading(true);
    try {
      rows = await api(config.endpoint);
      render();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  function render() {
    const q = document.getElementById("entitySearch").value.trim().toLowerCase();
    const filtered = !q ? rows : rows.filter(row =>
      Object.values(row).some(v => String(v ?? "").toLowerCase().includes(q))
    );

    const body = document.getElementById("entityTableBody");
    if (!filtered.length) {
      body.innerHTML = `<tr><td colspan="${config.columns.length + 1}">
        <div class="empty-state"><i class="bi bi-inbox"></i>No data found.</div>
      </td></tr>`;
      return;
    }

    body.innerHTML = filtered.map(row => {
      const cells = config.columns.map(([key, label, format]) =>
        `<td>${formatValue(row[key], format)}</td>`
      ).join("");

      const actions = (canEdit || canDelete) ? `
        <td class="text-end text-nowrap">
          ${canEdit ? `<button class="btn btn-sm btn-light btn-icon me-1" data-action="edit" data-id="${row.id}" title="Edit"><i class="bi bi-pencil"></i></button>` : ""}
          ${canDelete ? `<button class="btn btn-sm btn-light text-danger btn-icon" data-action="delete" data-id="${row.id}" title="Delete"><i class="bi bi-trash"></i></button>` : ""}
        </td>
      ` : "";

      return `<tr>${cells}${actions}</tr>`;
    }).join("");

    body.querySelectorAll("[data-action='edit']").forEach(btn =>
      btn.addEventListener("click", () => openModal(rows.find(x => String(x.id) === btn.dataset.id)))
    );

    body.querySelectorAll("[data-action='delete']").forEach(btn =>
      btn.addEventListener("click", () => remove(btn.dataset.id))
    );
  }

  function formatValue(value, format) {
    if (format === "money") return ui.money(value);
    if (format === "date") return ui.date(value);
    if (format === "datetime") return ui.dateTime(value);
    if (format === "badge") return ui.badge(value);
    if (format === "boolean") {
      return value
        ? `<span class="badge badge-soft-success">Active</span>`
        : `<span class="badge badge-soft-danger">Inactive</span>`;
    }
    if (format === "boolean-warning") {
      return value
        ? `<span class="badge badge-soft-warning">Low</span>`
        : `<span class="badge badge-soft-success">OK</span>`;
    }
    return ui.escapeHtml(value ?? "-");
  }

  async function openModal(row = null) {
    const isEdit = !!row;
    const fields = isEdit
      ? (config.editFields || config.fields)
      : (config.createFields || config.fields);

    document.getElementById("entityModalTitle").textContent =
      `${isEdit ? "Edit" : "Add"} ${config.title}`;

    const form = document.getElementById("entityForm");
    form.dataset.id = row?.id || "";
    form.innerHTML = `<div class="modal-body"><div class="row g-3">${(await Promise.all(fields.map(f => renderField(f, row)))).join("")}</div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" type="submit"><i class="bi bi-check-lg me-1"></i>Save</button></div>`;

    form.onsubmit = async e => {
      e.preventDefault();
      await save(row, fields);
    };

    modal = bootstrap.Modal.getOrCreateInstance(document.getElementById("entityModal"));
    modal.show();
  }

  async function renderField(field, row) {
    const value = row?.[field.name] ?? field.default ?? "";
    const required = field.required ? "required" : "";
    const col = field.col || 6;
    const id = `field_${field.name}`;

    if (field.type === "checkbox") {
      return `
        <div class="col-md-${col}">
          <div class="form-check form-switch mt-4 pt-2">
            <input class="form-check-input" type="checkbox" id="${id}" name="${field.name}" ${value ? "checked" : ""}>
            <label class="form-check-label fw-semibold" for="${id}">${ui.escapeHtml(field.label)}</label>
          </div>
        </div>
      `;
    }

    if (field.type === "textarea") {
      return `
        <div class="col-md-${col}">
          <label class="form-label">${ui.escapeHtml(field.label)}</label>
          <textarea class="form-control" id="${id}" name="${field.name}" rows="3" ${required}>${ui.escapeHtml(value)}</textarea>
        </div>
      `;
    }

    if (field.type === "select" || field.type === "select-api") {
      let options = field.options || [];
      if (field.type === "select-api") {
        const data = await api(field.endpoint);
        options = data.map(x => ({
          value: x[field.valueKey],
          text: x[field.textKey]
        }));
      } else {
        options = options.map(x => ({ value: x, text: x.replaceAll("_", " ") }));
      }

      return `
        <div class="col-md-${col}">
          <label class="form-label">${ui.escapeHtml(field.label)}</label>
          <select class="form-select" id="${id}" name="${field.name}" ${required}>
            <option value="">Select...</option>
            ${options.map(o => `<option value="${ui.escapeHtml(o.value)}" ${String(o.value) === String(value) ? "selected" : ""}>${ui.escapeHtml(o.text)}</option>`).join("")}
          </select>
        </div>
      `;
    }

    return `
      <div class="col-md-${col}">
        <label class="form-label">${ui.escapeHtml(field.label)}</label>
        <input
          class="form-control"
          id="${id}"
          name="${field.name}"
          type="${field.type || "text"}"
          value="${ui.escapeHtml(value)}"
          ${field.step ? `step="${field.step}"` : ""}
          ${required}
        >
      </div>
    `;
  }

  async function save(existing, fields) {
    const payload = {};
    fields.forEach(field => {
      const el = document.getElementById(`field_${field.name}`);
      if (!el) return;

      if (field.type === "checkbox") {
        payload[field.name] = el.checked;
      } else if (field.type === "number") {
        payload[field.name] = el.value === "" ? null : Number(el.value);
      } else {
        payload[field.name] = el.value === "" ? null : el.value;
      }
    });

    ui.showLoading(true);
    try {
      await api(existing ? `${config.endpoint}/${existing.id}` : config.endpoint, {
        method: existing ? "PUT" : "POST",
        body: payload
      });
      modal.hide();
      ui.toast(`${config.title} ${existing ? "updated" : "created"} successfully.`);
      await load();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  async function remove(id) {
    if (!await ui.confirmAction(`Delete this ${config.title.toLowerCase()}?`)) return;
    ui.showLoading(true);
    try {
      await api(`${config.endpoint}/${id}`, { method: "DELETE" });
      ui.toast(`${config.title} deleted successfully.`);
      await load();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  await load();
})();
