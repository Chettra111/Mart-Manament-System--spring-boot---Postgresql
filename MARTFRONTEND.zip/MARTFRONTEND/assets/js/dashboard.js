(async function () {
  const user = auth.currentUser();
  if (!user) return;

  function statCard(icon, iconClass, label, value) {
    return `
      <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
          <div class="stat-icon ${iconClass}"><i class="bi ${icon}"></i></div>
          <div class="stat-value">${value}</div>
          <div class="stat-label">${label}</div>
        </div>
      </div>
    `;
  }

  async function adminManagerDashboard() {
    const [summary, daily, top, low] = await Promise.all([
      api("/api/reports/dashboard"),
      api("/api/reports/sales/daily"),
      api("/api/reports/sales/top-products?limit=5"),
      api("/api/reports/stock/low")
    ]);

    document.getElementById("dashboardStats").innerHTML = [
      statCard("bi-cash-stack", "icon-green", "Total Sales", ui.money(summary.totalSales)),
      statCard("bi-cart-plus", "icon-blue", "Total Purchases", ui.money(summary.totalPurchases)),
      statCard("bi-graph-up-arrow", "icon-purple", "Gross Profit", ui.money(summary.grossProfit)),
      statCard("bi-exclamation-triangle", "icon-orange", "Low Stock Products", ui.number(summary.lowStockProducts)),
      statCard("bi-box-seam", "icon-cyan", "Products", ui.number(summary.totalProducts)),
      statCard("bi-people", "icon-blue", "Customers", ui.number(summary.totalCustomers)),
      statCard("bi-truck", "icon-purple", "Suppliers", ui.number(summary.totalSuppliers)),
      statCard("bi-person-badge", "icon-green", "Employees", ui.number(summary.totalEmployees))
    ].join("");

    renderChart(daily);
    renderTop(top);
    renderLow(low);
  }

  async function limitedDashboard() {
    const products = await api("/api/products");
    let customers = [];
    try { customers = await api("/api/customers"); } catch (_) {}

    document.getElementById("dashboardStats").innerHTML = [
      statCard("bi-box-seam", "icon-cyan", "Products", ui.number(products.length)),
      statCard("bi-exclamation-triangle", "icon-orange", "Low Stock", ui.number(products.filter(p => p.lowStock).length)),
      statCard("bi-check-circle", "icon-green", "Active Products", ui.number(products.filter(p => p.active).length)),
      statCard("bi-people", "icon-blue", "Customers", ui.number(customers.length))
    ].join("");

    document.querySelector("#dailySalesChart").closest(".content-card").innerHTML =
      `<div class="empty-state"><i class="bi bi-lock"></i>Detailed reporting is available to ADMIN and MANAGER roles.</div>`;
    document.getElementById("topProductsBody").innerHTML =
      `<tr><td colspan="5" class="text-center text-secondary py-4">Reporting access is restricted.</td></tr>`;

    renderLow(products.filter(p => p.lowStock));
  }

  function renderChart(rows) {
    const canvas = document.getElementById("dailySalesChart");
    if (!window.Chart || !canvas) return;

    const last = rows.slice(-14);
    new Chart(canvas, {
      type: "line",
      data: {
        labels: last.map(x => x.date),
        datasets: [{
          label: "Revenue",
          data: last.map(x => Number(x.revenue || 0)),
          borderWidth: 2,
          tension: .35,
          fill: false
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: { beginAtZero: true },
          x: { grid: { display: false } }
        }
      }
    });
  }

  function renderTop(rows) {
    document.getElementById("topProductsBody").innerHTML = rows.length
      ? rows.map(x => `
          <tr>
            <td><div class="fw-semibold">${ui.escapeHtml(x.productName)}</div><small class="text-secondary">${ui.escapeHtml(x.barcode)}</small></td>
            <td>${ui.escapeHtml(x.categoryName || "-")}</td>
            <td>${ui.number(x.quantitySold)}</td>
            <td>${ui.money(x.revenue)}</td>
            <td class="text-success fw-semibold">${ui.money(x.grossProfit)}</td>
          </tr>
        `).join("")
      : `<tr><td colspan="5" class="text-center text-secondary py-4">No sales data yet.</td></tr>`;
  }

  function renderLow(rows) {
    const el = document.getElementById("lowStockList");
    el.innerHTML = rows.length
      ? rows.slice(0, 8).map(x => `
          <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
            <div>
              <div class="fw-semibold">${ui.escapeHtml(x.productName || x.name)}</div>
              <small class="text-secondary">${ui.escapeHtml(x.barcode || "")}</small>
            </div>
            <span class="badge badge-soft-warning">${ui.number(x.stockQuantity)} left</span>
          </div>
        `).join("")
      : `<div class="empty-state py-4"><i class="bi bi-check-circle"></i>No low-stock products.</div>`;
  }

  ui.showLoading(true);
  try {
    if (["ADMIN", "MANAGER"].includes(user.role)) {
      await adminManagerDashboard();
    } else {
      await limitedDashboard();
    }
  } catch (err) {
    ui.toast(err.message, "danger");
  } finally {
    ui.showLoading(false);
  }
})();
