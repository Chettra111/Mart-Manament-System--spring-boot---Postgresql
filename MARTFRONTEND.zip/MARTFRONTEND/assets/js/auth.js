(function () {
  const cfg = window.MMS_CONFIG;

  function currentUser() {
    try {
      return JSON.parse(localStorage.getItem(cfg.USER_KEY) || "null");
    } catch (_) {
      return null;
    }
  }

  function token() {
    return localStorage.getItem(cfg.TOKEN_KEY);
  }

  function isLoggedIn() {
    return !!token();
  }

  function hasRole(...roles) {
    const user = currentUser();
    return !!user && roles.includes(user.role);
  }

  function requireAuth() {
    if (!isLoggedIn()) {
      location.href = "login.html";
      return false;
    }
    return true;
  }

  function logout() {
    localStorage.removeItem(cfg.TOKEN_KEY);
    localStorage.removeItem(cfg.USER_KEY);
    location.href = "login.html";
  }

  async function refreshCurrentUser() {
    const user = await api("/api/auth/me");
    localStorage.setItem(cfg.USER_KEY, JSON.stringify(user));
    return user;
  }

  window.auth = {
    currentUser,
    token,
    isLoggedIn,
    hasRole,
    requireAuth,
    logout,
    refreshCurrentUser
  };
})();
