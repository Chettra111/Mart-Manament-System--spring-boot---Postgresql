(async function () {
  let rows = [];
  let selected = null;
  const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById("adjustModal"));

  document.getElementById("stockSearch").addEventListener("input", render);
  document.getElementById("lowOnly").addEventListener("change", render);
  document.getElementById("adjustForm").addEventListener("submit", adjust);

  async function load() {
    ui.showLoading(true);
    try {
      rows = await api("/api/stock");
      document.getElementById("stockTotal").textContent = ui.number(rows.length);
      document.getElementById("stockLow").textContent = ui.number(rows.filter(x => x.lowStock).length);
      document.getElementById("stockUnits").textContent = ui.number(rows.reduce((s,x) => s + Number(x.stockQuantity || 0), 0));
      render();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  function render() {
    const q = document.getElementById("stockSearch").value.toLowerCase().trim();
    const low = document.getElementById("lowOnly").checked;
    const data = rows.filter(x =>
      (!low || x.lowStock) &&
      (!q || `${x.name} ${x.barcode} ${x.categoryName}`.toLowerCase().includes(q))
    );

    document.getElementById("stockTableBody").innerHTML = data.length
      ? data.map(x => `
        <tr>
          <td>${ui.escapeHtml(x.barcode)}</td>
          <td class="fw-semibold">${ui.escapeHtml(x.name)}</td>
          <td>${ui.escapeHtml(x.categoryName)}</td>
          <td><strong>${ui.number(x.stockQuantity)}</strong></td>
          <td>${ui.number(x.minimumStock)}</td>
          <td>${x.lowStock ? '<span class="badge badge-soft-warning">Low Stock</span>' : '<span class="badge badge-soft-success">OK</span>'}</td>
          <td class="text-end"><button class="btn btn-sm btn-outline-primary" onclick="stockPage.open(${x.id})"><i class="bi bi-sliders me-1"></i>Adjust</button></td>
        </tr>
      `).join("")
      : `<tr><td colspan="7"><div class="empty-state"><i class="bi bi-boxes"></i>No stock data found.</div></td></tr>`;
  }

  function open(id) {
    selected = rows.find(x => x.id === id);
    document.getElementById("adjustProductName").textContent = selected.name;
    document.getElementById("adjustCurrent").textContent = `Current stock: ${selected.stockQuantity}`;
    document.getElementById("quantityChange").value = "";
    document.getElementById("adjustReason").value = "";
    modal.show();
  }

  async function adjust(e) {
    e.preventDefault();
    ui.showLoading(true);
    try {
      await api(`/api/stock/products/${selected.id}/adjust`, {
        method: "PATCH",
        body: {
          quantityChange: Number(document.getElementById("quantityChange").value),
          reason: document.getElementById("adjustReason").value || null
        }
      });
      modal.hide();
      ui.toast("Stock adjusted successfully.");
      await load();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  window.stockPage = { open };
  await load();
})();
