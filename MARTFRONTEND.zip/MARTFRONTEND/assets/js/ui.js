(function () {
  function money(value) {
    const n = Number(value || 0);
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: window.MMS_CONFIG.CURRENCY || "USD",
      minimumFractionDigits: 2
    }).format(n);
  }

  function number(value) {
    return new Intl.NumberFormat("en-US").format(Number(value || 0));
  }

  function date(value) {
    if (!value) return "-";
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString();
  }

  function dateTime(value) {
    if (!value) return "-";
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? value : d.toLocaleString();
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function badge(value) {
    const v = String(value ?? "").toUpperCase();
    let cls = "badge-soft-secondary";
    if (["ACTIVE", "ENABLED", "SUCCESS", "COMPLETED"].includes(v)) cls = "badge-soft-success";
    if (["FAILED", "CANCELLED", "DISABLED", "INACTIVE"].includes(v)) cls = "badge-soft-danger";
    if (["PENDING", "LOW", "LOW_STOCK"].includes(v)) cls = "badge-soft-warning";
    if (["ADMIN", "MANAGER", "SCHEDULED", "MANUAL"].includes(v)) cls = "badge-soft-primary";
    return `<span class="badge ${cls}">${escapeHtml(value ?? "-")}</span>`;
  }

  function showLoading(show = true) {
    document.getElementById("loadingOverlay")?.classList.toggle("show", show);
  }

  function toast(message, type = "success") {
    const area = document.getElementById("toastArea") || createToastArea();
    const id = `toast-${Date.now()}`;
    const color = type === "danger" ? "text-bg-danger"
      : type === "warning" ? "text-bg-warning"
      : "text-bg-success";

    area.insertAdjacentHTML("beforeend", `
      <div id="${id}" class="toast ${color} border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
          <div class="toast-body">${escapeHtml(message)}</div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
      </div>
    `);

    const el = document.getElementById(id);
    const instance = bootstrap.Toast.getOrCreateInstance(el, { delay: 3500 });
    el.addEventListener("hidden.bs.toast", () => el.remove());
    instance.show();
  }

  function createToastArea() {
    const div = document.createElement("div");
    div.id = "toastArea";
    div.className = "toast-container position-fixed top-0 end-0 p-3";
    div.style.zIndex = "3000";
    document.body.appendChild(div);
    return div;
  }

  async function confirmAction(message, title = "Confirm") {
    return new Promise(resolve => {
      const id = "confirmModal";
      document.getElementById(id)?.remove();

      document.body.insertAdjacentHTML("beforeend", `
        <div class="modal fade" id="${id}" tabindex="-1">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">${escapeHtml(title)}</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body">${escapeHtml(message)}</div>
              <div class="modal-footer">
                <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button class="btn btn-danger" id="confirmYesBtn">Confirm</button>
              </div>
            </div>
          </div>
        </div>
      `);

      const el = document.getElementById(id);
      const modal = new bootstrap.Modal(el);
      let answered = false;

      el.querySelector("#confirmYesBtn").addEventListener("click", () => {
        answered = true;
        modal.hide();
        resolve(true);
      });

      el.addEventListener("hidden.bs.modal", () => {
        if (!answered) resolve(false);
        el.remove();
      });

      modal.show();
    });
  }

  window.ui = { money, number, date, dateTime, escapeHtml, badge, showLoading, toast, confirmAction };
})();
