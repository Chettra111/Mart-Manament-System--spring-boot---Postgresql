(async function () {
  let purchases = [];
  let suppliers = [];
  let employees = [];
  let products = [];
  let itemSeq = 0;

  const modal = bootstrap.Modal.getOrCreateInstance(document.getElementById("purchaseModal"));

  document.getElementById("newPurchaseBtn").addEventListener("click", openCreate);
  document.getElementById("addPurchaseItem").addEventListener("click", () => addItem());
  document.getElementById("purchaseSearch").addEventListener("input", render);
  document.getElementById("purchaseForm").addEventListener("submit", savePurchase);

  async function load() {
    ui.showLoading(true);
    try {
      const employeePromise = api("/api/employees").catch(() => []);
      [purchases, suppliers, employees, products] = await Promise.all([
        api("/api/purchases"),
        api("/api/suppliers"),
        employeePromise,
        api("/api/products")
      ]);
      render();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  function render() {
    const q = document.getElementById("purchaseSearch").value.trim().toLowerCase();
    const data = purchases.filter(x =>
      !q ||
      String(x.purchaseNumber || "").toLowerCase().includes(q) ||
      String(x.supplierName || "").toLowerCase().includes(q)
    );

    document.getElementById("purchaseTableBody").innerHTML = data.length
      ? data.map(x => `
        <tr>
          <td>${x.id}</td>
          <td class="fw-semibold">${ui.escapeHtml(x.purchaseNumber)}</td>
          <td>${ui.dateTime(x.purchaseDate)}</td>
          <td>${ui.escapeHtml(x.supplierName)}</td>
          <td>${ui.escapeHtml(x.employeeName)}</td>
          <td>${ui.badge(x.status)}</td>
          <td class="fw-semibold">${ui.money(x.total)}</td>
          <td class="text-end">
            <button class="btn btn-sm btn-light btn-icon me-1" onclick="purchasePage.view(${x.id})"><i class="bi bi-eye"></i></button>
            ${x.status === "COMPLETED" ? `<button class="btn btn-sm btn-light text-warning btn-icon" onclick="purchasePage.cancel(${x.id})"><i class="bi bi-x-circle"></i></button>` : ""}
          </td>
        </tr>
      `).join("")
      : `<tr><td colspan="8"><div class="empty-state"><i class="bi bi-bag"></i>No purchases found.</div></td></tr>`;
  }

  function openCreate() {
    document.getElementById("purchaseSupplier").innerHTML = `<option value="">Select supplier...</option>` +
      suppliers.filter(x => x.active).map(x => `<option value="${x.id}">${ui.escapeHtml(x.name)}</option>`).join("");
    const employeeSelect = document.getElementById("purchaseEmployee");
    if (employees.length) {
      employeeSelect.innerHTML = `<option value="">Select employee...</option>` +
        employees.filter(x => x.status === "ACTIVE").map(x => `<option value="${x.id}">${ui.escapeHtml(x.fullName)}</option>`).join("");
    } else {
      employeeSelect.innerHTML = `<option value="">Employee list restricted</option>`;
      const employeeId = prompt("Employee list is restricted for this role. Enter your Employee ID:");
      if (employeeId) {
        employeeSelect.innerHTML = `<option value="${Number(employeeId)}" selected>Employee ID ${Number(employeeId)}</option>`;
      }
    }
    document.getElementById("purchaseDate").value = "";
    document.getElementById("purchaseDiscount").value = "0";
    document.getElementById("purchaseTax").value = "0";
    document.getElementById("purchaseNotes").value = "";
    document.getElementById("purchaseItems").innerHTML = "";
    itemSeq = 0;
    addItem();
    modal.show();
  }

  function addItem() {
    const id = ++itemSeq;
    const wrap = document.createElement("div");
    wrap.className = "transaction-item-row";
    wrap.dataset.row = id;
    wrap.innerHTML = `
      <div class="product-field">
        <label class="form-label">Product</label>
        <select class="form-select item-product" required>
          <option value="">Select product...</option>
          ${products.filter(x => x.active).map(x => `<option value="${x.id}" data-cost="${x.purchasePrice}">${ui.escapeHtml(x.name)} (${ui.escapeHtml(x.barcode)})</option>`).join("")}
        </select>
      </div>
      <div>
        <label class="form-label">Qty</label>
        <input type="number" min="1" step="1" value="1" class="form-control item-qty" required>
      </div>
      <div>
        <label class="form-label">Unit Cost</label>
        <input type="number" min="0.01" step="0.01" class="form-control item-cost" required>
      </div>
      <div class="remove-field">
        <button type="button" class="btn btn-outline-danger btn-icon w-100 remove-item"><i class="bi bi-trash"></i></button>
      </div>
    `;
    document.getElementById("purchaseItems").appendChild(wrap);

    wrap.querySelector(".item-product").addEventListener("change", e => {
      const opt = e.target.selectedOptions[0];
      wrap.querySelector(".item-cost").value = opt?.dataset.cost || "";
      updateTotal();
    });
    wrap.querySelector(".item-qty").addEventListener("input", updateTotal);
    wrap.querySelector(".item-cost").addEventListener("input", updateTotal);
    wrap.querySelector(".remove-item").addEventListener("click", () => {
      wrap.remove();
      updateTotal();
    });
    updateTotal();
  }

  function getItems() {
    return [...document.querySelectorAll("#purchaseItems .transaction-item-row")].map(row => ({
      productId: Number(row.querySelector(".item-product").value),
      quantity: Number(row.querySelector(".item-qty").value),
      unitCost: Number(row.querySelector(".item-cost").value)
    })).filter(x => x.productId);
  }

  function updateTotal() {
    const subtotal = getItems().reduce((s, x) => s + x.quantity * x.unitCost, 0);
    const discount = Number(document.getElementById("purchaseDiscount").value || 0);
    const tax = Number(document.getElementById("purchaseTax").value || 0);
    document.getElementById("purchaseEstimatedTotal").textContent = ui.money(subtotal - discount + tax);
  }

  document.getElementById("purchaseDiscount").addEventListener("input", updateTotal);
  document.getElementById("purchaseTax").addEventListener("input", updateTotal);

  async function savePurchase(e) {
    e.preventDefault();
    const items = getItems();
    if (!items.length) {
      ui.toast("Add at least one purchase item.", "warning");
      return;
    }

    const date = document.getElementById("purchaseDate").value;
    const payload = {
      supplierId: Number(document.getElementById("purchaseSupplier").value),
      employeeId: Number(document.getElementById("purchaseEmployee").value),
      purchaseDate: date || null,
      discount: Number(document.getElementById("purchaseDiscount").value || 0),
      tax: Number(document.getElementById("purchaseTax").value || 0),
      notes: document.getElementById("purchaseNotes").value || null,
      items
    };

    ui.showLoading(true);
    try {
      await api("/api/purchases", { method: "POST", body: payload });
      modal.hide();
      ui.toast("Purchase created. Product stock increased.");
      await load();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  async function view(id) {
    const x = await api(`/api/purchases/${id}`);
    document.getElementById("purchaseDetailBody").innerHTML = `
      <div class="row g-2 mb-3">
        <div class="col-md-6"><strong>Purchase:</strong> ${ui.escapeHtml(x.purchaseNumber)}</div>
        <div class="col-md-6"><strong>Status:</strong> ${ui.badge(x.status)}</div>
        <div class="col-md-6"><strong>Supplier:</strong> ${ui.escapeHtml(x.supplierName)}</div>
        <div class="col-md-6"><strong>Employee:</strong> ${ui.escapeHtml(x.employeeName)}</div>
      </div>
      <div class="table-responsive">
        <table class="table table-sm">
          <thead><tr><th>Product</th><th>Qty</th><th>Unit Cost</th><th>Total</th></tr></thead>
          <tbody>${x.items.map(i => `<tr><td>${ui.escapeHtml(i.productName)}</td><td>${i.quantity}</td><td>${ui.money(i.unitCost)}</td><td>${ui.money(i.lineTotal)}</td></tr>`).join("")}</tbody>
          <tfoot><tr><th colspan="3" class="text-end">Grand Total</th><th>${ui.money(x.total)}</th></tr></tfoot>
        </table>
      </div>
    `;
    bootstrap.Modal.getOrCreateInstance(document.getElementById("purchaseDetailModal")).show();
  }

  async function cancel(id) {
    if (!await ui.confirmAction("Cancel this purchase? Stock will be reversed.")) return;
    ui.showLoading(true);
    try {
      await api(`/api/purchases/${id}/cancel`, { method: "POST" });
      ui.toast("Purchase cancelled.");
      await load();
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  window.purchasePage = { view, cancel };
  await load();
})();
