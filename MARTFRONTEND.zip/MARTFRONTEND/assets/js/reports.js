(function () {
  let lastRows = [];
  let lastColumns = [];

  const configs = {
    daily: {
      title: "Daily Sales",
      endpoint: "/api/reports/sales/daily",
      dateFilter: true,
      columns: [
        ["date","Date"],["transactionCount","Transactions"],["itemsSold","Items Sold"],
        ["revenue","Revenue","money"],["estimatedCost","Est. Cost","money"],["grossProfit","Gross Profit","money"]
      ]
    },
    monthly: {
      title: "Monthly Sales",
      endpoint: "/api/reports/sales/monthly",
      yearFilter: true,
      columns: [
        ["month","Month"],["transactionCount","Transactions"],["itemsSold","Items Sold"],
        ["revenue","Revenue","money"],["estimatedCost","Est. Cost","money"],["grossProfit","Gross Profit","money"]
      ]
    },
    top: {
      title: "Top Products",
      endpoint: "/api/reports/sales/top-products",
      dateFilter: true,
      extra: "limit=20",
      columns: [
        ["barcode","Barcode"],["productName","Product"],["categoryName","Category"],
        ["quantitySold","Qty Sold"],["revenue","Revenue","money"],["grossProfit","Gross Profit","money"]
      ]
    },
    employee: {
      title: "Sales by Employee",
      endpoint: "/api/reports/sales/by-employee",
      dateFilter: true,
      columns: [
        ["employeeCode","Code"],["employeeName","Employee"],["transactionCount","Transactions"],
        ["itemsSold","Items Sold"],["revenue","Revenue","money"]
      ]
    },
    sales: {
      title: "Sale Transactions",
      endpoint: "/api/reports/sales/transactions",
      dateFilter: true,
      columns: [
        ["invoiceNumber","Invoice"],["saleDate","Date","datetime"],["customerName","Customer"],
        ["employeeName","Employee"],["status","Status","badge"],["total","Total","money"]
      ]
    },
    purchases: {
      title: "Purchase Transactions",
      endpoint: "/api/reports/purchases/transactions",
      dateFilter: true,
      columns: [
        ["purchaseNumber","Purchase No."],["purchaseDate","Date","datetime"],["supplierName","Supplier"],
        ["employeeName","Employee"],["status","Status","badge"],["total","Total","money"]
      ]
    },
    stock: {
      title: "Stock Report",
      endpoint: "/api/reports/stock",
      columns: [
        ["barcode","Barcode"],["productName","Product"],["categoryName","Category"],
        ["stockQuantity","Stock"],["minimumStock","Minimum"],["stockCostValue","Cost Value","money"],
        ["stockRetailValue","Retail Value","money"],["lowStock","Status","low"]
      ]
    },
    lowstock: {
      title: "Low Stock Report",
      endpoint: "/api/reports/stock/low",
      columns: [
        ["barcode","Barcode"],["productName","Product"],["categoryName","Category"],
        ["stockQuantity","Stock"],["minimumStock","Minimum"],["sellingPrice","Selling Price","money"]
      ]
    },
    profit: {
      title: "Profit Summary",
      endpoint: "/api/reports/profit",
      dateFilter: true,
      single: true,
      columns: [
        ["salesRevenue","Sales Revenue","money"],["estimatedCost","Estimated Cost","money"],
        ["grossProfit","Gross Profit","money"],["purchaseExpense","Purchase Expense","money"],["itemsSold","Items Sold"]
      ]
    }
  };

  document.getElementById("runReportBtn").addEventListener("click", run);
  document.getElementById("exportCsvBtn").addEventListener("click", exportCsv);

  async function run() {
    const key = document.getElementById("reportType").value;
    const cfg = configs[key];
    const params = new URLSearchParams();

    if (cfg.dateFilter) {
      const from = document.getElementById("fromDate").value;
      const to = document.getElementById("toDate").value;
      if (from) params.set("fromDate", from);
      if (to) params.set("toDate", to);
    }

    if (cfg.yearFilter) {
      const year = document.getElementById("reportYear").value;
      if (year) params.set("year", year);
    }

    if (cfg.extra) {
      const [k,v] = cfg.extra.split("=");
      params.set(k,v);
    }

    ui.showLoading(true);
    try {
      const result = await api(`${cfg.endpoint}${params.toString() ? "?" + params : ""}`);
      lastRows = cfg.single ? [result] : result;
      lastColumns = cfg.columns;

      document.getElementById("reportTitle").textContent = cfg.title;
      document.getElementById("reportMeta").textContent = `${lastRows.length} row(s)`;

      renderTable(lastRows, cfg.columns);
      renderSummary(key, result);
    } catch (err) {
      ui.toast(err.message, "danger");
    } finally {
      ui.showLoading(false);
    }
  }

  function renderTable(rows, columns) {
    document.getElementById("reportHead").innerHTML =
      `<tr>${columns.map(c => `<th>${ui.escapeHtml(c[1])}</th>`).join("")}</tr>`;

    document.getElementById("reportBody").innerHTML = rows.length
      ? rows.map(row => `<tr>${columns.map(c => `<td>${fmt(row[c[0]], c[2])}</td>`).join("")}</tr>`).join("")
      : `<tr><td colspan="${columns.length}"><div class="empty-state"><i class="bi bi-bar-chart"></i>No report data.</div></td></tr>`;
  }

  function fmt(v, f) {
    if (f === "money") return ui.money(v);
    if (f === "date") return ui.date(v);
    if (f === "datetime") return ui.dateTime(v);
    if (f === "badge") return ui.badge(v);
    if (f === "low") return v ? '<span class="badge badge-soft-warning">Low</span>' : '<span class="badge badge-soft-success">OK</span>';
    return ui.escapeHtml(v ?? "-");
  }

  function renderSummary(key, result) {
    const el = document.getElementById("reportSummary");
    if (key !== "profit") {
      el.innerHTML = "";
      return;
    }

    el.innerHTML = `
      <div class="col-md-3"><div class="stat-card"><div class="stat-label">Sales Revenue</div><div class="stat-value text-success">${ui.money(result.salesRevenue)}</div></div></div>
      <div class="col-md-3"><div class="stat-card"><div class="stat-label">Estimated Cost</div><div class="stat-value">${ui.money(result.estimatedCost)}</div></div></div>
      <div class="col-md-3"><div class="stat-card"><div class="stat-label">Gross Profit</div><div class="stat-value text-primary">${ui.money(result.grossProfit)}</div></div></div>
      <div class="col-md-3"><div class="stat-card"><div class="stat-label">Items Sold</div><div class="stat-value">${ui.number(result.itemsSold)}</div></div></div>
    `;
  }

  function exportCsv() {
    if (!lastRows.length) {
      ui.toast("Run a report first.", "warning");
      return;
    }

    const headers = lastColumns.map(c => c[1]);
    const data = lastRows.map(row => lastColumns.map(c => row[c[0]] ?? ""));
    const csv = [headers, ...data]
      .map(row => row.map(v => `"${String(v).replaceAll('"','""')}"`).join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `mart-report-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  document.getElementById("reportYear").value = new Date().getFullYear();
  run();
})();
