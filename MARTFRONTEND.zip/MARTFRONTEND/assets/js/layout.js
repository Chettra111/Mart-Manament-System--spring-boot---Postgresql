(function () {
  if (!auth.requireAuth()) return;

  const user = auth.currentUser() || {};
  const current = document.body.dataset.page || "dashboard";

  const groups = [
    {
      label: "Overview",
      items: [
        ["dashboard", "index.html", "bi-grid", "Dashboard", ["ADMIN","MANAGER","CASHIER","STOCK_KEEPER"]]
      ]
    },
    {
      label: "Operation",
      items: [
        ["categories", "categories.html", "bi-tags", "Categories", ["ADMIN","MANAGER","CASHIER","STOCK_KEEPER"]],
        ["products", "products.html", "bi-box-seam", "Products", ["ADMIN","MANAGER","CASHIER","STOCK_KEEPER"]],
        ["suppliers", "suppliers.html", "bi-truck", "Suppliers", ["ADMIN","MANAGER","STOCK_KEEPER"]],
        ["customers", "customers.html", "bi-people", "Customers", ["ADMIN","MANAGER","CASHIER","STOCK_KEEPER"]],
        ["employees", "employees.html", "bi-person-badge", "Employees", ["ADMIN","MANAGER"]],
        ["purchases", "purchases.html", "bi-bag-plus", "Purchases", ["ADMIN","MANAGER","STOCK_KEEPER"]],
        ["sales", "sales.html", "bi-receipt", "Sales", ["ADMIN","MANAGER","CASHIER"]],
        ["stock", "stock.html", "bi-boxes", "Stock", ["ADMIN","MANAGER","STOCK_KEEPER"]]
      ]
    },
    {
      label: "System",
      items: [
        ["reports", "reports.html", "bi-bar-chart-line", "Reports", ["ADMIN","MANAGER"]],
        ["users", "users.html", "bi-shield-lock", "User Management", ["ADMIN"]]
      ]
    }
  ];

  const allowed = roles => roles.includes(user.role);

  const navHtml = groups.map(group => {
    const links = group.items
      .filter(item => allowed(item[4]))
      .map(([key, href, icon, label]) => `
        <a class="sidebar-link ${current === key ? "active" : ""}" href="${href}">
          <i class="bi ${icon}"></i>
          <span>${label}</span>
        </a>
      `).join("");

    return links ? `<div class="sidebar-label">${group.label}</div>${links}` : "";
  }).join("");

  const sidebar = `
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-brand">
        <div class="logo"><i class="bi bi-shop"></i></div>
        <div>
          <div class="fw-bold text-white">Mart MS</div>
          <div class="small text-secondary">Management System</div>
        </div>
      </div>
      <nav class="sidebar-nav">${navHtml}</nav>
    </aside>
  `;

  const topbar = `
    <header class="topbar">
      <div class="d-flex align-items-center gap-3">
        <button class="btn btn-light mobile-menu-btn" id="mobileMenuBtn">
          <i class="bi bi-list"></i>
        </button>
        <div>
          <div class="fw-semibold d-none d-sm-block">Mart Management System</div>
          <div class="small text-secondary d-none d-md-block">API Gateway: ${window.MMS_CONFIG.API_BASE_URL}</div>
        </div>
      </div>

      <div class="dropdown">
        <button class="btn border-0 bg-transparent dropdown-toggle p-0" data-bs-toggle="dropdown">
          <span class="user-chip">
            <span class="text-end d-none d-sm-block">
              <span class="d-block fw-semibold">${ui.escapeHtml(user.username || "User")}</span>
              <span class="d-block small text-secondary">${ui.escapeHtml(user.role || "")}</span>
            </span>
            <span class="user-avatar">${ui.escapeHtml((user.username || "U").slice(0,1).toUpperCase())}</span>
          </span>
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow-sm">
          <li><span class="dropdown-item-text small text-secondary">${ui.escapeHtml(user.email || "")}</span></li>
          <li><hr class="dropdown-divider"></li>
          <li><button class="dropdown-item text-danger" id="logoutBtn"><i class="bi bi-box-arrow-right me-2"></i>Logout</button></li>
        </ul>
      </div>
    </header>
  `;

  document.getElementById("appSidebar").innerHTML = sidebar;
  document.getElementById("appTopbar").innerHTML = topbar;

  document.getElementById("logoutBtn")?.addEventListener("click", auth.logout);
  document.getElementById("mobileMenuBtn")?.addEventListener("click", () => {
    document.getElementById("sidebar")?.classList.toggle("show");
  });

  document.body.insertAdjacentHTML("beforeend", `
    <div class="loading-overlay" id="loadingOverlay">
      <div class="loading-box">
        <div class="spinner-border spinner-border-sm text-primary"></div>
        <span>Loading...</span>
      </div>
    </div>
  `);
})();
