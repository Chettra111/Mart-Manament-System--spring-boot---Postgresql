@echo off
title Mart Management System Front-End
echo.
echo Starting Front-End at http://localhost:5500/login.html
echo.
python -m http.server 5500
pause
