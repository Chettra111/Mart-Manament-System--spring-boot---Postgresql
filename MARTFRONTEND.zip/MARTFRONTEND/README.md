# MARTFRONTEND — Mart Management System Front-End

A Bootstrap + Vanilla JavaScript front-end for the Spring Boot microservices project.

## Architecture

```text
Browser Front-End
      |
      | http://localhost:8080
      v
API Gateway
  |-- Auth Service       :8081
  |-- Operation Service  :8082
  |-- Reporting Service  :8083
  `-- CRON Service       :8084
```

The browser calls **only the API Gateway (port 8080)**.

## Pages

- Login
- Dashboard
- Categories
- Products
- Suppliers
- Customers
- Employees
- Purchases
- Sales
- Stock
- Reports
- CRON Jobs
- User Management

## Requirements

Start these backend services first:

1. Auth Service — `8081`
2. Operation Service — `8082`
3. Reporting Service — `8083`
4. CRON Service — `8084`
5. API Gateway — `8080`

## Run Front-End

### Option 1 — VS Code Live Server

Open `MARTFRONTEND` in VS Code.

Right-click `login.html` -> **Open with Live Server**.

### Option 2 — Python

Open a terminal inside this folder:

```powershell
python -m http.server 5500
```

Then open:

```text
http://localhost:5500/login.html
```

## Default Login

```text
Username: admin
Password: Admin@123
```

## API Base URL

Default:

```text
http://localhost:8080
```

It is configured in:

```text
assets/js/config.js
```

## Security

After login, the JWT is stored in browser `localStorage` and automatically sent as:

```http
Authorization: Bearer <TOKEN>
```

Role-aware navigation is included for:

- ADMIN
- MANAGER
- CASHIER
- STOCK_KEEPER

## Notes

Bootstrap, Bootstrap Icons, and Chart.js are loaded from CDN, so internet access is needed for those visual libraries.
