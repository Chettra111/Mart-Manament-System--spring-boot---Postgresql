-- Connect to mart_management_db before running this script manually.
CREATE SCHEMA IF NOT EXISTS reporting;
