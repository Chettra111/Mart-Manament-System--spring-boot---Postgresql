-- Run this only if the shared database does not already exist.
CREATE DATABASE mart_management_db;

-- The application automatically creates the reporting schema from schema.sql.
