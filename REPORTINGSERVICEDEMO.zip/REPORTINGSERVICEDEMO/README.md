# REPORTINGSERVICEDEMO

Reporting microservice for the Mart Management System.

## Technology

- Java 21
- Spring Boot 4.1.0
- Maven
- PostgreSQL
- Spring Security
- JWT
- Spring JDBC for report queries
- Spring Data JPA for report history

## Project structure

```text
REPORTINGSERVICEDEMO/
├── src/main/java/reportingservice/reportingservicedemo/
│   ├── ReportingservicedemoApplication.java
│   ├── config/
│   ├── controller/
│   ├── dto/
│   ├── entity/
│   ├── exception/
│   ├── repository/
│   ├── security/
│   └── service/
├── src/main/resources/
│   ├── application.properties
│   └── schema.sql
├── database/create_database.sql
├── postman-reporting-service.json
├── pom.xml
├── mvnw
└── mvnw.cmd
```

## Database design

All services use one PostgreSQL database:

```text
mart_management_db
```

Schemas:

```text
auth       -> Auth Service
operation  -> Operation Service
reporting  -> Reporting Service
```

The Reporting Service reads business data from the `operation` schema and stores report history in:

```text
reporting.report_runs
```

## Configuration

Open:

```text
src/main/resources/application.properties
```

Change the PostgreSQL password when necessary:

```properties
spring.datasource.password=postgres
```

The JWT secret must be the same in Auth Service, Operation Service, and Reporting Service:

```properties
app.jwt.secret=Fv7/YT6BJviXt2U812YUCUPhcyA7MpFLfrmwAtBlJc4=
```

## Run services

Run Auth Service:

```powershell
cd AUTHSERVICEDEMO
.\mvnw.cmd spring-boot:run
```

Run Operation Service:

```powershell
cd OPERATIONSERVICEDEMO
.\mvnw.cmd spring-boot:run
```

Run Reporting Service:

```powershell
cd REPORTINGSERVICEDEMO
.\mvnw.cmd spring-boot:run
```

Default ports:

```text
Auth Service       http://localhost:8081
Operation Service  http://localhost:8082
Reporting Service  http://localhost:8083
```

## Security

Reporting endpoints require an Auth Service JWT token.

Allowed roles:

```text
ADMIN
MANAGER
```

Report history endpoints require:

```text
ADMIN
```

Use this header:

```text
Authorization: Bearer YOUR_TOKEN
```

## Report endpoints

```text
GET /api/reports/dashboard
GET /api/reports/sales/daily
GET /api/reports/sales/monthly
GET /api/reports/sales/top-products
GET /api/reports/sales/by-employee
GET /api/reports/sales/transactions
GET /api/reports/purchases/transactions
GET /api/reports/stock
GET /api/reports/stock/low
GET /api/reports/profit
GET /api/report-runs
GET /api/report-runs/{id}
```

Date parameters use this format:

```text
YYYY-MM-DD
```

Example:

```text
http://localhost:8083/api/reports/dashboard?fromDate=2026-07-01&toDate=2026-07-31
```

When dates are omitted, the service uses the latest 30 days.

## Profit calculation note

The Operation Service stores the selling price on each sale item, but it does not store a historical purchase cost on each sale item. Therefore, estimated cost and gross profit use the product's current `purchase_price`:

```text
Estimated cost = quantity sold × current product purchase price
Gross profit   = sales revenue - estimated cost
```

This is suitable for the midterm project. For a larger real system, store `unit_cost` on every sale item at the time of sale.
