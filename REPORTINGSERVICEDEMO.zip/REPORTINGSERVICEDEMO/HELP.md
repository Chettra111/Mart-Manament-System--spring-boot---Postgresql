# Reporting Service

Run from the project root:

```powershell
.\mvnw.cmd spring-boot:run
```

Default URL: `http://localhost:8083`
