package reportingservice.reportingservicedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReportingservicedemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReportingservicedemoApplication.class, args);
    }
}
