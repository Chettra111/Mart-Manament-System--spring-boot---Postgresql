package reportingservice.reportingservicedemo.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reportingservice.reportingservicedemo.dto.ReportRunResponse;
import reportingservice.reportingservicedemo.entity.ReportRun;
import reportingservice.reportingservicedemo.exception.ResourceNotFoundException;
import reportingservice.reportingservicedemo.repository.ReportRunRepository;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class ReportRunService {

    private final ReportRunRepository reportRunRepository;

    public ReportRunService(ReportRunRepository reportRunRepository) {
        this.reportRunRepository = reportRunRepository;
    }

    public List<ReportRunResponse> findAll() {
        return reportRunRepository.findAllByOrderByGeneratedAtDesc()
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public ReportRunResponse findById(Long id) {
        ReportRun run = reportRunRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Report run not found with id: " + id));
        return toResponse(run);
    }

    private ReportRunResponse toResponse(ReportRun run) {
        return new ReportRunResponse(
                run.getId(),
                run.getReportType(),
                run.getGeneratedBy(),
                run.getParameters(),
                run.getRowCount(),
                run.getGeneratedAt()
        );
    }
}
