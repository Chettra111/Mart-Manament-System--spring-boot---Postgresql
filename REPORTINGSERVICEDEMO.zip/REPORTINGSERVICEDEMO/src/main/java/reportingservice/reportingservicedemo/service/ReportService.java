package reportingservice.reportingservicedemo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reportingservice.reportingservicedemo.dto.DailySalesReportResponse;
import reportingservice.reportingservicedemo.dto.DashboardSummaryResponse;
import reportingservice.reportingservicedemo.dto.EmployeeSalesReportResponse;
import reportingservice.reportingservicedemo.dto.MonthlySalesReportResponse;
import reportingservice.reportingservicedemo.dto.ProfitReportResponse;
import reportingservice.reportingservicedemo.dto.PurchaseTransactionReportResponse;
import reportingservice.reportingservicedemo.dto.SaleTransactionReportResponse;
import reportingservice.reportingservicedemo.dto.StockReportResponse;
import reportingservice.reportingservicedemo.dto.TopProductReportResponse;
import reportingservice.reportingservicedemo.entity.ReportRun;
import reportingservice.reportingservicedemo.entity.ReportType;
import reportingservice.reportingservicedemo.exception.BusinessException;
import reportingservice.reportingservicedemo.repository.ReportQueryRepository;
import reportingservice.reportingservicedemo.repository.ReportRunRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Year;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Service
@Transactional
public class ReportService {

    private static final Set<String> TRANSACTION_STATUSES = Set.of("COMPLETED", "CANCELLED");

    private final ReportQueryRepository queryRepository;
    private final ReportRunRepository reportRunRepository;
    private final int defaultDays;

    public ReportService(
            ReportQueryRepository queryRepository,
            ReportRunRepository reportRunRepository,
            @Value("${app.report.default-days:30}") int defaultDays
    ) {
        this.queryRepository = queryRepository;
        this.reportRunRepository = reportRunRepository;
        this.defaultDays = defaultDays;
    }

    public DashboardSummaryResponse dashboard(
            LocalDate fromDate,
            LocalDate toDate,
            String username
    ) {
        DateRange range = resolveRange(fromDate, toDate);
        DashboardSummaryResponse response = queryRepository.dashboard(
                range.fromDate(),
                range.toDate(),
                range.from(),
                range.toExclusive()
        );
        log(ReportType.DASHBOARD, username, range.parameters(), 1);
        return response;
    }

    public List<DailySalesReportResponse> dailySales(
            LocalDate fromDate,
            LocalDate toDate,
            String username
    ) {
        DateRange range = resolveRange(fromDate, toDate);
        List<DailySalesReportResponse> rows = queryRepository.dailySales(
                range.from(), range.toExclusive());
        log(ReportType.DAILY_SALES, username, range.parameters(), rows.size());
        return rows;
    }

    public List<MonthlySalesReportResponse> monthlySales(Integer year, String username) {
        int reportYear = year == null ? Year.now().getValue() : year;
        if (reportYear < 2000 || reportYear > 2100) {
            throw new BusinessException("Year must be between 2000 and 2100");
        }
        List<MonthlySalesReportResponse> rows = queryRepository.monthlySales(reportYear);
        log(ReportType.MONTHLY_SALES, username, "year=" + reportYear, rows.size());
        return rows;
    }

    public List<TopProductReportResponse> topProducts(
            LocalDate fromDate,
            LocalDate toDate,
            Integer limit,
            String username
    ) {
        DateRange range = resolveRange(fromDate, toDate);
        int actualLimit = limit == null ? 10 : limit;
        if (actualLimit < 1 || actualLimit > 100) {
            throw new BusinessException("Limit must be between 1 and 100");
        }
        List<TopProductReportResponse> rows = queryRepository.topProducts(
                range.from(), range.toExclusive(), actualLimit);
        log(
                ReportType.TOP_PRODUCTS,
                username,
                range.parameters() + ", limit=" + actualLimit,
                rows.size()
        );
        return rows;
    }

    public List<EmployeeSalesReportResponse> employeeSales(
            LocalDate fromDate,
            LocalDate toDate,
            String username
    ) {
        DateRange range = resolveRange(fromDate, toDate);
        List<EmployeeSalesReportResponse> rows = queryRepository.employeeSales(
                range.from(), range.toExclusive());
        log(ReportType.EMPLOYEE_SALES, username, range.parameters(), rows.size());
        return rows;
    }

    public List<SaleTransactionReportResponse> saleTransactions(
            LocalDate fromDate,
            LocalDate toDate,
            String status,
            String username
    ) {
        DateRange range = resolveRange(fromDate, toDate);
        String normalizedStatus = normalizeStatus(status);
        List<SaleTransactionReportResponse> rows = queryRepository.saleTransactions(
                range.from(), range.toExclusive(), normalizedStatus);
        log(
                ReportType.SALE_TRANSACTIONS,
                username,
                range.parameters() + ", status=" + displayStatus(normalizedStatus),
                rows.size()
        );
        return rows;
    }

    public List<PurchaseTransactionReportResponse> purchaseTransactions(
            LocalDate fromDate,
            LocalDate toDate,
            String status,
            String username
    ) {
        DateRange range = resolveRange(fromDate, toDate);
        String normalizedStatus = normalizeStatus(status);
        List<PurchaseTransactionReportResponse> rows = queryRepository.purchaseTransactions(
                range.from(), range.toExclusive(), normalizedStatus);
        log(
                ReportType.PURCHASE_TRANSACTIONS,
                username,
                range.parameters() + ", status=" + displayStatus(normalizedStatus),
                rows.size()
        );
        return rows;
    }

    public List<StockReportResponse> stock(boolean lowOnly, String username) {
        List<StockReportResponse> rows = queryRepository.stock(lowOnly);
        log(
                lowOnly ? ReportType.LOW_STOCK : ReportType.STOCK,
                username,
                "lowOnly=" + lowOnly,
                rows.size()
        );
        return rows;
    }

    public ProfitReportResponse profit(
            LocalDate fromDate,
            LocalDate toDate,
            String username
    ) {
        DateRange range = resolveRange(fromDate, toDate);
        ProfitReportResponse response = queryRepository.profit(
                range.fromDate(),
                range.toDate(),
                range.from(),
                range.toExclusive()
        );
        log(ReportType.PROFIT, username, range.parameters(), 1);
        return response;
    }

    private DateRange resolveRange(LocalDate fromDate, LocalDate toDate) {
        LocalDate resolvedTo = toDate == null ? LocalDate.now() : toDate;
        LocalDate resolvedFrom = fromDate == null
                ? resolvedTo.minusDays(Math.max(defaultDays - 1L, 0L))
                : fromDate;

        if (resolvedFrom.isAfter(resolvedTo)) {
            throw new BusinessException("fromDate cannot be after toDate");
        }

        return new DateRange(
                resolvedFrom,
                resolvedTo,
                resolvedFrom.atStartOfDay(),
                resolvedTo.plusDays(1).atStartOfDay()
        );
    }

    private String normalizeStatus(String status) {
        if (status == null || status.isBlank() || status.equalsIgnoreCase("ALL")) {
            return null;
        }
        String normalized = status.trim().toUpperCase(Locale.ROOT);
        if (!TRANSACTION_STATUSES.contains(normalized)) {
            throw new BusinessException("Status must be COMPLETED, CANCELLED, or ALL");
        }
        return normalized;
    }

    private String displayStatus(String status) {
        return status == null ? "ALL" : status;
    }

    private void log(ReportType type, String username, String parameters, int rowCount) {
        ReportRun run = new ReportRun();
        run.setReportType(type);
        run.setGeneratedBy(
                username == null || username.isBlank() ? "unknown" : username);
        run.setParameters(parameters);
        run.setRowCount(rowCount);
        reportRunRepository.save(run);
    }

    private record DateRange(
            LocalDate fromDate,
            LocalDate toDate,
            LocalDateTime from,
            LocalDateTime toExclusive
    ) {
        String parameters() {
            return "fromDate=" + fromDate + ", toDate=" + toDate;
        }
    }
}
