package reportingservice.reportingservicedemo.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record PurchaseTransactionReportResponse(
        Long id,
        String purchaseNumber,
        LocalDateTime purchaseDate,
        String supplierName,
        String employeeName,
        String status,
        BigDecimal subtotal,
        BigDecimal discount,
        BigDecimal tax,
        BigDecimal total
) {
}
