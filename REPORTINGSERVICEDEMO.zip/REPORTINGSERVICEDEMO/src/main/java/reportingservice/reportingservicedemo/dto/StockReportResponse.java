package reportingservice.reportingservicedemo.dto;

import java.math.BigDecimal;

public record StockReportResponse(
        Long productId,
        String barcode,
        String productName,
        String categoryName,
        int stockQuantity,
        int minimumStock,
        BigDecimal purchasePrice,
        BigDecimal sellingPrice,
        BigDecimal stockCostValue,
        BigDecimal stockRetailValue,
        boolean lowStock,
        boolean active
) {
}
