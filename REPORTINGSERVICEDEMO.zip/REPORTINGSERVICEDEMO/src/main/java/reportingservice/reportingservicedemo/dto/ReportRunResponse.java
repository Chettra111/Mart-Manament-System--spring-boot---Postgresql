package reportingservice.reportingservicedemo.dto;

import reportingservice.reportingservicedemo.entity.ReportType;

import java.time.Instant;

public record ReportRunResponse(
        Long id,
        ReportType reportType,
        String generatedBy,
        String parameters,
        Integer rowCount,
        Instant generatedAt
) {
}
