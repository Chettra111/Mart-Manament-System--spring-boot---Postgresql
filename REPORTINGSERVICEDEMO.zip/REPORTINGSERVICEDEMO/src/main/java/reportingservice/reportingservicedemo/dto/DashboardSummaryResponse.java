package reportingservice.reportingservicedemo.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public record DashboardSummaryResponse(
        LocalDate fromDate,
        LocalDate toDate,
        BigDecimal totalSales,
        BigDecimal totalPurchases,
        BigDecimal estimatedCost,
        BigDecimal grossProfit,
        long completedSales,
        long completedPurchases,
        long totalProducts,
        long lowStockProducts,
        long totalCustomers,
        long totalSuppliers,
        long totalEmployees
) {
}
