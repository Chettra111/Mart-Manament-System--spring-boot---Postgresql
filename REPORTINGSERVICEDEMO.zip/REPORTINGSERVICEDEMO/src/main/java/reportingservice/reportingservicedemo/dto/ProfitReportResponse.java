package reportingservice.reportingservicedemo.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public record ProfitReportResponse(
        LocalDate fromDate,
        LocalDate toDate,
        BigDecimal salesRevenue,
        BigDecimal estimatedCost,
        BigDecimal grossProfit,
        BigDecimal purchaseExpense,
        long itemsSold
) {
}
