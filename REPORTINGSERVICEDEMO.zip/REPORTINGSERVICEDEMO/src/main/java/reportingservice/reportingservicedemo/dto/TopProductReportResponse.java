package reportingservice.reportingservicedemo.dto;

import java.math.BigDecimal;

public record TopProductReportResponse(
        Long productId,
        String barcode,
        String productName,
        String categoryName,
        long quantitySold,
        BigDecimal revenue,
        BigDecimal estimatedCost,
        BigDecimal grossProfit
) {
}
