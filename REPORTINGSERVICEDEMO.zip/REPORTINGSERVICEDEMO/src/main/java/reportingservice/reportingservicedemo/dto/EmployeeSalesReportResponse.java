package reportingservice.reportingservicedemo.dto;

import java.math.BigDecimal;

public record EmployeeSalesReportResponse(
        Long employeeId,
        String employeeCode,
        String employeeName,
        long transactionCount,
        long itemsSold,
        BigDecimal revenue
) {
}
