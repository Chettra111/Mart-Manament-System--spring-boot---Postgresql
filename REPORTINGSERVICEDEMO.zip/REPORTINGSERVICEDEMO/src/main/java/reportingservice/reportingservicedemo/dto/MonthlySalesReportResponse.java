package reportingservice.reportingservicedemo.dto;

import java.math.BigDecimal;

public record MonthlySalesReportResponse(
        String month,
        long transactionCount,
        long itemsSold,
        BigDecimal subtotal,
        BigDecimal discount,
        BigDecimal tax,
        BigDecimal revenue,
        BigDecimal estimatedCost,
        BigDecimal grossProfit
) {
}
