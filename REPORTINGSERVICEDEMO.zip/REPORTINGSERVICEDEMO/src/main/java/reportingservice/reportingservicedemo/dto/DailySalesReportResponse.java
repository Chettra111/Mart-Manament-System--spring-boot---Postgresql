package reportingservice.reportingservicedemo.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public record DailySalesReportResponse(
        LocalDate date,
        long transactionCount,
        long itemsSold,
        BigDecimal subtotal,
        BigDecimal discount,
        BigDecimal tax,
        BigDecimal revenue,
        BigDecimal estimatedCost,
        BigDecimal grossProfit
) {
}
