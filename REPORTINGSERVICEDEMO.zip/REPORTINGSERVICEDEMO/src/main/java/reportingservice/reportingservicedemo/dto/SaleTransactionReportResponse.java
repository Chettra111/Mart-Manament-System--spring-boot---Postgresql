package reportingservice.reportingservicedemo.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record SaleTransactionReportResponse(
        Long id,
        String invoiceNumber,
        LocalDateTime saleDate,
        String customerName,
        String employeeName,
        String status,
        BigDecimal subtotal,
        BigDecimal discount,
        BigDecimal tax,
        BigDecimal total,
        BigDecimal amountPaid,
        BigDecimal changeAmount
) {
}
