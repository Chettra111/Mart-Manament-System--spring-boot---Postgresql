package reportingservice.reportingservicedemo.controller;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reportingservice.reportingservicedemo.dto.DailySalesReportResponse;
import reportingservice.reportingservicedemo.dto.DashboardSummaryResponse;
import reportingservice.reportingservicedemo.dto.EmployeeSalesReportResponse;
import reportingservice.reportingservicedemo.dto.MonthlySalesReportResponse;
import reportingservice.reportingservicedemo.dto.ProfitReportResponse;
import reportingservice.reportingservicedemo.dto.PurchaseTransactionReportResponse;
import reportingservice.reportingservicedemo.dto.SaleTransactionReportResponse;
import reportingservice.reportingservicedemo.dto.StockReportResponse;
import reportingservice.reportingservicedemo.dto.TopProductReportResponse;
import reportingservice.reportingservicedemo.service.ReportService;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    private final ReportService reportService;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/dashboard")
    public DashboardSummaryResponse dashboard(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            Authentication authentication
    ) {
        return reportService.dashboard(fromDate, toDate, authentication.getName());
    }

    @GetMapping("/sales/daily")
    public List<DailySalesReportResponse> dailySales(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            Authentication authentication
    ) {
        return reportService.dailySales(fromDate, toDate, authentication.getName());
    }

    @GetMapping("/sales/monthly")
    public List<MonthlySalesReportResponse> monthlySales(
            @RequestParam(required = false) Integer year,
            Authentication authentication
    ) {
        return reportService.monthlySales(year, authentication.getName());
    }

    @GetMapping("/sales/top-products")
    public List<TopProductReportResponse> topProducts(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(required = false) Integer limit,
            Authentication authentication
    ) {
        return reportService.topProducts(
                fromDate, toDate, limit, authentication.getName());
    }

    @GetMapping("/sales/by-employee")
    public List<EmployeeSalesReportResponse> employeeSales(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            Authentication authentication
    ) {
        return reportService.employeeSales(fromDate, toDate, authentication.getName());
    }

    @GetMapping("/sales/transactions")
    public List<SaleTransactionReportResponse> saleTransactions(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(required = false, defaultValue = "COMPLETED") String status,
            Authentication authentication
    ) {
        return reportService.saleTransactions(
                fromDate, toDate, status, authentication.getName());
    }

    @GetMapping("/purchases/transactions")
    public List<PurchaseTransactionReportResponse> purchaseTransactions(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(required = false, defaultValue = "COMPLETED") String status,
            Authentication authentication
    ) {
        return reportService.purchaseTransactions(
                fromDate, toDate, status, authentication.getName());
    }

    @GetMapping("/stock")
    public List<StockReportResponse> stock(Authentication authentication) {
        return reportService.stock(false, authentication.getName());
    }

    @GetMapping("/stock/low")
    public List<StockReportResponse> lowStock(Authentication authentication) {
        return reportService.stock(true, authentication.getName());
    }

    @GetMapping("/profit")
    public ProfitReportResponse profit(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            Authentication authentication
    ) {
        return reportService.profit(fromDate, toDate, authentication.getName());
    }
}
