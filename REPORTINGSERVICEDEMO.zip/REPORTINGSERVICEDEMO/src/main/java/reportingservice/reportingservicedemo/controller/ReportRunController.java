package reportingservice.reportingservicedemo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reportingservice.reportingservicedemo.dto.ReportRunResponse;
import reportingservice.reportingservicedemo.service.ReportRunService;

import java.util.List;

@RestController
@RequestMapping("/api/report-runs")
public class ReportRunController {

    private final ReportRunService reportRunService;

    public ReportRunController(ReportRunService reportRunService) {
        this.reportRunService = reportRunService;
    }

    @GetMapping
    public List<ReportRunResponse> findAll() {
        return reportRunService.findAll();
    }

    @GetMapping("/{id}")
    public ReportRunResponse findById(@PathVariable Long id) {
        return reportRunService.findById(id);
    }
}
