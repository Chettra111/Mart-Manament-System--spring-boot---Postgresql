package reportingservice.reportingservicedemo.entity;

public enum ReportType {
    DASHBOARD,
    DAILY_SALES,
    MONTHLY_SALES,
    TOP_PRODUCTS,
    EMPLOYEE_SALES,
    SALE_TRANSACTIONS,
    PURCHASE_TRANSACTIONS,
    STOCK,
    LOW_STOCK,
    PROFIT
}
