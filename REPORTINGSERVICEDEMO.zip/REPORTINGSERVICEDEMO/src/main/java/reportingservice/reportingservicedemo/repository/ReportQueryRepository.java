package reportingservice.reportingservicedemo.repository;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import reportingservice.reportingservicedemo.dto.DailySalesReportResponse;
import reportingservice.reportingservicedemo.dto.DashboardSummaryResponse;
import reportingservice.reportingservicedemo.dto.EmployeeSalesReportResponse;
import reportingservice.reportingservicedemo.dto.MonthlySalesReportResponse;
import reportingservice.reportingservicedemo.dto.ProfitReportResponse;
import reportingservice.reportingservicedemo.dto.PurchaseTransactionReportResponse;
import reportingservice.reportingservicedemo.dto.SaleTransactionReportResponse;
import reportingservice.reportingservicedemo.dto.StockReportResponse;
import reportingservice.reportingservicedemo.dto.TopProductReportResponse;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class ReportQueryRepository {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    public ReportQueryRepository(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public DashboardSummaryResponse dashboard(
            LocalDate fromDate,
            LocalDate toDate,
            LocalDateTime from,
            LocalDateTime toExclusive
    ) {
        String sql = """
                WITH sales_summary AS (
                    SELECT
                        COUNT(*) AS completed_sales,
                        COALESCE(SUM(total), 0) AS total_sales
                    FROM operation.sales
                    WHERE status = 'COMPLETED'
                      AND sale_date >= :from
                      AND sale_date < :toExclusive
                ),
                cost_summary AS (
                    SELECT COALESCE(SUM(si.quantity * p.purchase_price), 0) AS estimated_cost
                    FROM operation.sale_items si
                    JOIN operation.sales s ON s.id = si.sale_id
                    JOIN operation.products p ON p.id = si.product_id
                    WHERE s.status = 'COMPLETED'
                      AND s.sale_date >= :from
                      AND s.sale_date < :toExclusive
                ),
                purchase_summary AS (
                    SELECT
                        COUNT(*) AS completed_purchases,
                        COALESCE(SUM(total), 0) AS total_purchases
                    FROM operation.purchases
                    WHERE status = 'COMPLETED'
                      AND purchase_date >= :from
                      AND purchase_date < :toExclusive
                )
                SELECT
                    ss.total_sales,
                    ps.total_purchases,
                    cs.estimated_cost,
                    (ss.total_sales - cs.estimated_cost) AS gross_profit,
                    ss.completed_sales,
                    ps.completed_purchases,
                    (SELECT COUNT(*) FROM operation.products WHERE active = true) AS total_products,
                    (SELECT COUNT(*) FROM operation.products
                     WHERE active = true AND stock_quantity <= minimum_stock) AS low_stock_products,
                    (SELECT COUNT(*) FROM operation.customers WHERE active = true) AS total_customers,
                    (SELECT COUNT(*) FROM operation.suppliers WHERE active = true) AS total_suppliers,
                    (SELECT COUNT(*) FROM operation.employees WHERE status = 'ACTIVE') AS total_employees
                FROM sales_summary ss
                CROSS JOIN cost_summary cs
                CROSS JOIN purchase_summary ps
                """;

        MapSqlParameterSource params = dateParams(from, toExclusive);
        return jdbcTemplate.queryForObject(sql, params, (rs, rowNum) ->
                new DashboardSummaryResponse(
                        fromDate,
                        toDate,
                        money(rs, "total_sales"),
                        money(rs, "total_purchases"),
                        money(rs, "estimated_cost"),
                        money(rs, "gross_profit"),
                        rs.getLong("completed_sales"),
                        rs.getLong("completed_purchases"),
                        rs.getLong("total_products"),
                        rs.getLong("low_stock_products"),
                        rs.getLong("total_customers"),
                        rs.getLong("total_suppliers"),
                        rs.getLong("total_employees")
                ));
    }

    public List<DailySalesReportResponse> dailySales(LocalDateTime from, LocalDateTime toExclusive) {
        String sql = """
                WITH sale_daily AS (
                    SELECT
                        CAST(sale_date AS date) AS report_date,
                        COUNT(*) AS transaction_count,
                        COALESCE(SUM(subtotal), 0) AS subtotal,
                        COALESCE(SUM(discount), 0) AS discount,
                        COALESCE(SUM(tax), 0) AS tax,
                        COALESCE(SUM(total), 0) AS revenue
                    FROM operation.sales
                    WHERE status = 'COMPLETED'
                      AND sale_date >= :from
                      AND sale_date < :toExclusive
                    GROUP BY CAST(sale_date AS date)
                ),
                item_daily AS (
                    SELECT
                        CAST(s.sale_date AS date) AS report_date,
                        COALESCE(SUM(si.quantity), 0) AS items_sold,
                        COALESCE(SUM(si.quantity * p.purchase_price), 0) AS estimated_cost
                    FROM operation.sales s
                    JOIN operation.sale_items si ON si.sale_id = s.id
                    JOIN operation.products p ON p.id = si.product_id
                    WHERE s.status = 'COMPLETED'
                      AND s.sale_date >= :from
                      AND s.sale_date < :toExclusive
                    GROUP BY CAST(s.sale_date AS date)
                )
                SELECT
                    sd.report_date,
                    sd.transaction_count,
                    COALESCE(id.items_sold, 0) AS items_sold,
                    sd.subtotal,
                    sd.discount,
                    sd.tax,
                    sd.revenue,
                    COALESCE(id.estimated_cost, 0) AS estimated_cost,
                    (sd.revenue - COALESCE(id.estimated_cost, 0)) AS gross_profit
                FROM sale_daily sd
                LEFT JOIN item_daily id ON id.report_date = sd.report_date
                ORDER BY sd.report_date
                """;

        return jdbcTemplate.query(sql, dateParams(from, toExclusive), (rs, rowNum) ->
                new DailySalesReportResponse(
                        rs.getObject("report_date", LocalDate.class),
                        rs.getLong("transaction_count"),
                        rs.getLong("items_sold"),
                        money(rs, "subtotal"),
                        money(rs, "discount"),
                        money(rs, "tax"),
                        money(rs, "revenue"),
                        money(rs, "estimated_cost"),
                        money(rs, "gross_profit")
                ));
    }

    public List<MonthlySalesReportResponse> monthlySales(int year) {
        String sql = """
                WITH sale_monthly AS (
                    SELECT
                        TO_CHAR(sale_date, 'YYYY-MM') AS report_month,
                        COUNT(*) AS transaction_count,
                        COALESCE(SUM(subtotal), 0) AS subtotal,
                        COALESCE(SUM(discount), 0) AS discount,
                        COALESCE(SUM(tax), 0) AS tax,
                        COALESCE(SUM(total), 0) AS revenue
                    FROM operation.sales
                    WHERE status = 'COMPLETED'
                      AND EXTRACT(YEAR FROM sale_date) = :year
                    GROUP BY TO_CHAR(sale_date, 'YYYY-MM')
                ),
                item_monthly AS (
                    SELECT
                        TO_CHAR(s.sale_date, 'YYYY-MM') AS report_month,
                        COALESCE(SUM(si.quantity), 0) AS items_sold,
                        COALESCE(SUM(si.quantity * p.purchase_price), 0) AS estimated_cost
                    FROM operation.sales s
                    JOIN operation.sale_items si ON si.sale_id = s.id
                    JOIN operation.products p ON p.id = si.product_id
                    WHERE s.status = 'COMPLETED'
                      AND EXTRACT(YEAR FROM s.sale_date) = :year
                    GROUP BY TO_CHAR(s.sale_date, 'YYYY-MM')
                )
                SELECT
                    sm.report_month,
                    sm.transaction_count,
                    COALESCE(im.items_sold, 0) AS items_sold,
                    sm.subtotal,
                    sm.discount,
                    sm.tax,
                    sm.revenue,
                    COALESCE(im.estimated_cost, 0) AS estimated_cost,
                    (sm.revenue - COALESCE(im.estimated_cost, 0)) AS gross_profit
                FROM sale_monthly sm
                LEFT JOIN item_monthly im ON im.report_month = sm.report_month
                ORDER BY sm.report_month
                """;

        return jdbcTemplate.query(sql, new MapSqlParameterSource("year", year), (rs, rowNum) ->
                new MonthlySalesReportResponse(
                        rs.getString("report_month"),
                        rs.getLong("transaction_count"),
                        rs.getLong("items_sold"),
                        money(rs, "subtotal"),
                        money(rs, "discount"),
                        money(rs, "tax"),
                        money(rs, "revenue"),
                        money(rs, "estimated_cost"),
                        money(rs, "gross_profit")
                ));
    }

    public List<TopProductReportResponse> topProducts(
            LocalDateTime from,
            LocalDateTime toExclusive,
            int limit
    ) {
        String sql = """
                SELECT
                    p.id AS product_id,
                    p.barcode,
                    p.name AS product_name,
                    c.name AS category_name,
                    COALESCE(SUM(si.quantity), 0) AS quantity_sold,
                    COALESCE(SUM(si.line_total), 0) AS revenue,
                    COALESCE(SUM(si.quantity * p.purchase_price), 0) AS estimated_cost,
                    COALESCE(SUM(si.line_total - (si.quantity * p.purchase_price)), 0) AS gross_profit
                FROM operation.sale_items si
                JOIN operation.sales s ON s.id = si.sale_id
                JOIN operation.products p ON p.id = si.product_id
                JOIN operation.categories c ON c.id = p.category_id
                WHERE s.status = 'COMPLETED'
                  AND s.sale_date >= :from
                  AND s.sale_date < :toExclusive
                GROUP BY p.id, p.barcode, p.name, c.name
                ORDER BY quantity_sold DESC, revenue DESC
                LIMIT :limit
                """;

        MapSqlParameterSource params = dateParams(from, toExclusive)
                .addValue("limit", limit);
        return jdbcTemplate.query(sql, params, (rs, rowNum) ->
                new TopProductReportResponse(
                        rs.getLong("product_id"),
                        rs.getString("barcode"),
                        rs.getString("product_name"),
                        rs.getString("category_name"),
                        rs.getLong("quantity_sold"),
                        money(rs, "revenue"),
                        money(rs, "estimated_cost"),
                        money(rs, "gross_profit")
                ));
    }

    public List<EmployeeSalesReportResponse> employeeSales(
            LocalDateTime from,
            LocalDateTime toExclusive
    ) {
        String sql = """
                SELECT
                    e.id AS employee_id,
                    e.code AS employee_code,
                    CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
                    COUNT(DISTINCT s.id) AS transaction_count,
                    COALESCE(SUM(si.quantity), 0) AS items_sold,
                    COALESCE(SUM(si.line_total), 0) AS revenue
                FROM operation.employees e
                JOIN operation.sales s ON s.employee_id = e.id
                LEFT JOIN operation.sale_items si ON si.sale_id = s.id
                WHERE s.status = 'COMPLETED'
                  AND s.sale_date >= :from
                  AND s.sale_date < :toExclusive
                GROUP BY e.id, e.code, e.first_name, e.last_name
                ORDER BY revenue DESC, transaction_count DESC
                """;

        return jdbcTemplate.query(sql, dateParams(from, toExclusive), (rs, rowNum) ->
                new EmployeeSalesReportResponse(
                        rs.getLong("employee_id"),
                        rs.getString("employee_code"),
                        rs.getString("employee_name"),
                        rs.getLong("transaction_count"),
                        rs.getLong("items_sold"),
                        money(rs, "revenue")
                ));
    }

    public List<StockReportResponse> stock(boolean lowOnly) {
        String sql = """
                SELECT
                    p.id AS product_id,
                    p.barcode,
                    p.name AS product_name,
                    c.name AS category_name,
                    p.stock_quantity,
                    p.minimum_stock,
                    p.purchase_price,
                    p.selling_price,
                    (p.stock_quantity * p.purchase_price) AS stock_cost_value,
                    (p.stock_quantity * p.selling_price) AS stock_retail_value,
                    (p.stock_quantity <= p.minimum_stock) AS low_stock,
                    p.active
                FROM operation.products p
                JOIN operation.categories c ON c.id = p.category_id
                WHERE (:lowOnly = false OR p.stock_quantity <= p.minimum_stock)
                ORDER BY low_stock DESC, p.stock_quantity ASC, p.name ASC
                """;

        return jdbcTemplate.query(
                sql,
                new MapSqlParameterSource("lowOnly", lowOnly),
                (rs, rowNum) -> new StockReportResponse(
                        rs.getLong("product_id"),
                        rs.getString("barcode"),
                        rs.getString("product_name"),
                        rs.getString("category_name"),
                        rs.getInt("stock_quantity"),
                        rs.getInt("minimum_stock"),
                        money(rs, "purchase_price"),
                        money(rs, "selling_price"),
                        money(rs, "stock_cost_value"),
                        money(rs, "stock_retail_value"),
                        rs.getBoolean("low_stock"),
                        rs.getBoolean("active")
                ));
    }

    public List<SaleTransactionReportResponse> saleTransactions(
            LocalDateTime from,
            LocalDateTime toExclusive,
            String status
    ) {
        StringBuilder sql = new StringBuilder("""
                SELECT
                    s.id,
                    s.invoice_number,
                    s.sale_date,
                    COALESCE(c.name, 'Walk-in Customer') AS customer_name,
                    CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
                    s.status,
                    s.subtotal,
                    s.discount,
                    s.tax,
                    s.total,
                    s.amount_paid,
                    s.change_amount
                FROM operation.sales s
                LEFT JOIN operation.customers c ON c.id = s.customer_id
                JOIN operation.employees e ON e.id = s.employee_id
                WHERE s.sale_date >= :from
                  AND s.sale_date < :toExclusive
                """);

        MapSqlParameterSource params = dateParams(from, toExclusive);
        if (status != null) {
            sql.append(" AND s.status = :status ");
            params.addValue("status", status);
        }
        sql.append(" ORDER BY s.sale_date DESC, s.id DESC ");

        return jdbcTemplate.query(sql.toString(), params, (rs, rowNum) ->
                new SaleTransactionReportResponse(
                        rs.getLong("id"),
                        rs.getString("invoice_number"),
                        rs.getObject("sale_date", LocalDateTime.class),
                        rs.getString("customer_name"),
                        rs.getString("employee_name"),
                        rs.getString("status"),
                        money(rs, "subtotal"),
                        money(rs, "discount"),
                        money(rs, "tax"),
                        money(rs, "total"),
                        money(rs, "amount_paid"),
                        money(rs, "change_amount")
                ));
    }

    public List<PurchaseTransactionReportResponse> purchaseTransactions(
            LocalDateTime from,
            LocalDateTime toExclusive,
            String status
    ) {
        StringBuilder sql = new StringBuilder("""
                SELECT
                    p.id,
                    p.purchase_number,
                    p.purchase_date,
                    s.name AS supplier_name,
                    CONCAT(e.first_name, ' ', e.last_name) AS employee_name,
                    p.status,
                    p.subtotal,
                    p.discount,
                    p.tax,
                    p.total
                FROM operation.purchases p
                JOIN operation.suppliers s ON s.id = p.supplier_id
                JOIN operation.employees e ON e.id = p.employee_id
                WHERE p.purchase_date >= :from
                  AND p.purchase_date < :toExclusive
                """);

        MapSqlParameterSource params = dateParams(from, toExclusive);
        if (status != null) {
            sql.append(" AND p.status = :status ");
            params.addValue("status", status);
        }
        sql.append(" ORDER BY p.purchase_date DESC, p.id DESC ");

        return jdbcTemplate.query(sql.toString(), params, (rs, rowNum) ->
                new PurchaseTransactionReportResponse(
                        rs.getLong("id"),
                        rs.getString("purchase_number"),
                        rs.getObject("purchase_date", LocalDateTime.class),
                        rs.getString("supplier_name"),
                        rs.getString("employee_name"),
                        rs.getString("status"),
                        money(rs, "subtotal"),
                        money(rs, "discount"),
                        money(rs, "tax"),
                        money(rs, "total")
                ));
    }

    public ProfitReportResponse profit(
            LocalDate fromDate,
            LocalDate toDate,
            LocalDateTime from,
            LocalDateTime toExclusive
    ) {
        String sql = """
                WITH sales_summary AS (
                    SELECT COALESCE(SUM(total), 0) AS sales_revenue
                    FROM operation.sales
                    WHERE status = 'COMPLETED'
                      AND sale_date >= :from
                      AND sale_date < :toExclusive
                ),
                item_summary AS (
                    SELECT
                        COALESCE(SUM(si.quantity), 0) AS items_sold,
                        COALESCE(SUM(si.quantity * p.purchase_price), 0) AS estimated_cost
                    FROM operation.sale_items si
                    JOIN operation.sales s ON s.id = si.sale_id
                    JOIN operation.products p ON p.id = si.product_id
                    WHERE s.status = 'COMPLETED'
                      AND s.sale_date >= :from
                      AND s.sale_date < :toExclusive
                ),
                purchase_summary AS (
                    SELECT COALESCE(SUM(total), 0) AS purchase_expense
                    FROM operation.purchases
                    WHERE status = 'COMPLETED'
                      AND purchase_date >= :from
                      AND purchase_date < :toExclusive
                )
                SELECT
                    ss.sales_revenue,
                    isx.estimated_cost,
                    (ss.sales_revenue - isx.estimated_cost) AS gross_profit,
                    ps.purchase_expense,
                    isx.items_sold
                FROM sales_summary ss
                CROSS JOIN item_summary isx
                CROSS JOIN purchase_summary ps
                """;

        return jdbcTemplate.queryForObject(sql, dateParams(from, toExclusive), (rs, rowNum) ->
                new ProfitReportResponse(
                        fromDate,
                        toDate,
                        money(rs, "sales_revenue"),
                        money(rs, "estimated_cost"),
                        money(rs, "gross_profit"),
                        money(rs, "purchase_expense"),
                        rs.getLong("items_sold")
                ));
    }

    private MapSqlParameterSource dateParams(LocalDateTime from, LocalDateTime toExclusive) {
        return new MapSqlParameterSource()
                .addValue("from", from)
                .addValue("toExclusive", toExclusive);
    }

    private BigDecimal money(ResultSet rs, String column) throws SQLException {
        BigDecimal value = rs.getBigDecimal(column);
        return value == null ? BigDecimal.ZERO : value;
    }
}
