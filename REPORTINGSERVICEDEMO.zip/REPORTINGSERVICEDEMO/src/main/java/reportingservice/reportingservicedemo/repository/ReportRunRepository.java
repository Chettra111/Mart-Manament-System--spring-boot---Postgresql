package reportingservice.reportingservicedemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import reportingservice.reportingservicedemo.entity.ReportRun;

import java.util.List;

public interface ReportRunRepository extends JpaRepository<ReportRun, Long> {

    List<ReportRun> findAllByOrderByGeneratedAtDesc();
}
