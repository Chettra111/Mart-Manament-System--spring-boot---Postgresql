package reportingservice.reportingservicedemo;

import org.junit.jupiter.api.Test;
import reportingservice.reportingservicedemo.entity.ReportType;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ReportTypeTest {

    @Test
    void reportTypeContainsDashboard() {
        assertEquals(ReportType.DASHBOARD, ReportType.valueOf("DASHBOARD"));
    }
}
