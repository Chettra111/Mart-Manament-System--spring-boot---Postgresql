-- Run this once in PostgreSQL or pgAdmin while connected as postgres.
CREATE DATABASE mart_management_db;
