package authservice.authservicedemo.dto;

import jakarta.validation.constraints.Email;

public record UpdateUserRequest(
        @Email(message = "Email format is invalid")
        String email,

        String role,

        Boolean enabled
) {
}
