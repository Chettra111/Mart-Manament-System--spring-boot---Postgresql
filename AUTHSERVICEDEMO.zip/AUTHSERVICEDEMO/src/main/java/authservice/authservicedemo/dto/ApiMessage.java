package authservice.authservicedemo.dto;

public record ApiMessage(String message) {
}
