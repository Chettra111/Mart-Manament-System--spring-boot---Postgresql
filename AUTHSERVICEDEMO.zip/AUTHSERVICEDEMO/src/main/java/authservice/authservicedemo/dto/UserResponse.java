package authservice.authservicedemo.dto;

import authservice.authservicedemo.entity.AppUser;

import java.time.LocalDateTime;

public record UserResponse(
        Long id,
        String username,
        String email,
        boolean enabled,
        String role,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
    public static UserResponse from(AppUser user) {
        return new UserResponse(
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.isEnabled(),
                user.getRole().getName().name(),
                user.getCreatedAt(),
                user.getUpdatedAt()
        );
    }
}
