package authservice.authservicedemo.service;

import authservice.authservicedemo.dto.CreateUserRequest;
import authservice.authservicedemo.dto.UpdateUserRequest;
import authservice.authservicedemo.dto.UserResponse;
import authservice.authservicedemo.entity.AppUser;
import authservice.authservicedemo.entity.Role;
import authservice.authservicedemo.entity.RoleName;
import authservice.authservicedemo.exception.ConflictException;
import authservice.authservicedemo.exception.ResourceNotFoundException;
import authservice.authservicedemo.repository.AppUserRepository;
import authservice.authservicedemo.repository.RoleRepository;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {

    private final AppUserRepository appUserRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(
            AppUserRepository appUserRepository,
            RoleRepository roleRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.appUserRepository = appUserRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional(readOnly = true)
    public List<UserResponse> findAll() {
        return appUserRepository.findAll(Sort.by(Sort.Direction.ASC, "id"))
                .stream()
                .map(UserResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public UserResponse findById(Long id) {
        return UserResponse.from(getUser(id));
    }

    @Transactional(readOnly = true)
    public UserResponse findByUsername(String username) {
        AppUser user = appUserRepository.findByUsernameIgnoreCase(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return UserResponse.from(user);
    }

    @Transactional
    public UserResponse create(CreateUserRequest request) {
        if (appUserRepository.existsByUsernameIgnoreCase(request.username().trim())) {
            throw new ConflictException("Username is already in use");
        }

        if (appUserRepository.existsByEmailIgnoreCase(request.email().trim())) {
            throw new ConflictException("Email is already in use");
        }

        AppUser user = new AppUser();
        user.setUsername(request.username().trim());
        user.setEmail(request.email().trim().toLowerCase());
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setEnabled(true);
        user.setRole(getRole(request.role()));

        return UserResponse.from(appUserRepository.save(user));
    }

    @Transactional
    public UserResponse update(Long id, UpdateUserRequest request) {
        AppUser user = getUser(id);

        if (request.email() != null && !request.email().isBlank()) {
            String email = request.email().trim().toLowerCase();
            if (appUserRepository.existsByEmailIgnoreCaseAndIdNot(email, id)) {
                throw new ConflictException("Email is already in use");
            }
            user.setEmail(email);
        }

        if (request.role() != null && !request.role().isBlank()) {
            user.setRole(getRole(request.role()));
        }

        if (request.enabled() != null) {
            user.setEnabled(request.enabled());
        }

        return UserResponse.from(appUserRepository.save(user));
    }

    @Transactional
    public void delete(Long id) {
        AppUser user = getUser(id);
        appUserRepository.delete(user);
    }

    private AppUser getUser(Long id) {
        return appUserRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User with ID " + id + " was not found"));
    }

    private Role getRole(String roleValue) {
        RoleName roleName;
        try {
            roleName = RoleName.valueOf(roleValue.trim().toUpperCase());
        } catch (IllegalArgumentException exception) {
            throw new IllegalArgumentException(
                    "Invalid role. Use ADMIN, MANAGER, CASHIER, or STOCK_KEEPER"
            );
        }

        return roleRepository.findByName(roleName)
                .orElseThrow(() -> new ResourceNotFoundException("Role was not found"));
    }
}
