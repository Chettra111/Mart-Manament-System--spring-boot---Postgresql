package authservice.authservicedemo.service;

import authservice.authservicedemo.dto.AuthResponse;
import authservice.authservicedemo.dto.LoginRequest;
import authservice.authservicedemo.dto.RegisterRequest;
import authservice.authservicedemo.dto.UserResponse;
import authservice.authservicedemo.entity.AppUser;
import authservice.authservicedemo.entity.Role;
import authservice.authservicedemo.entity.RoleName;
import authservice.authservicedemo.exception.ConflictException;
import authservice.authservicedemo.repository.AppUserRepository;
import authservice.authservicedemo.repository.RoleRepository;
import authservice.authservicedemo.security.CustomUserDetailsService;
import authservice.authservicedemo.security.JwtService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final AppUserRepository appUserRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final CustomUserDetailsService userDetailsService;
    private final JwtService jwtService;

    public AuthService(
            AuthenticationManager authenticationManager,
            AppUserRepository appUserRepository,
            RoleRepository roleRepository,
            PasswordEncoder passwordEncoder,
            CustomUserDetailsService userDetailsService,
            JwtService jwtService
    ) {
        this.authenticationManager = authenticationManager;
        this.appUserRepository = appUserRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.userDetailsService = userDetailsService;
        this.jwtService = jwtService;
    }

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        validateUniqueUser(request.username(), request.email());

        Role defaultRole = roleRepository.findByName(RoleName.CASHIER)
                .orElseThrow(() -> new IllegalStateException("CASHIER role is missing"));

        AppUser user = new AppUser();
        user.setUsername(request.username().trim());
        user.setEmail(request.email().trim().toLowerCase());
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setEnabled(true);
        user.setRole(defaultRole);

        AppUser savedUser = appUserRepository.save(user);
        return createAuthResponse(savedUser);
    }

    public AuthResponse login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.username(),
                        request.password()
                )
        );

        AppUser user = appUserRepository.findByUsernameIgnoreCase(request.username())
                .orElseThrow(() -> new IllegalStateException("Authenticated user was not found"));

        return createAuthResponse(user);
    }

    private AuthResponse createAuthResponse(AppUser user) {
        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getUsername());
        String token = jwtService.generateToken(userDetails);

        return new AuthResponse(
                token,
                "Bearer",
                jwtService.getExpirationMs() / 1000,
                UserResponse.from(user)
        );
    }

    private void validateUniqueUser(String username, String email) {
        if (appUserRepository.existsByUsernameIgnoreCase(username.trim())) {
            throw new ConflictException("Username is already in use");
        }

        if (appUserRepository.existsByEmailIgnoreCase(email.trim())) {
            throw new ConflictException("Email is already in use");
        }
    }
}
