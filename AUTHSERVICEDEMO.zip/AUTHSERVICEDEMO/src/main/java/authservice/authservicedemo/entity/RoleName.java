package authservice.authservicedemo.entity;

public enum RoleName {
    ADMIN,
    MANAGER,
    CASHIER,
    STOCK_KEEPER
}
