package authservice.authservicedemo.controller;

import authservice.authservicedemo.entity.RoleName;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/roles")
public class RoleController {

    @GetMapping
    public List<String> findAll() {
        return Arrays.stream(RoleName.values())
                .map(Enum::name)
                .toList();
    }
}
