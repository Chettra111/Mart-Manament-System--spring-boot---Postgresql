package authservice.authservicedemo;

import authservice.authservicedemo.entity.RoleName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RoleNameTest {

    @Test
    void shouldContainFourRoles() {
        assertEquals(4, RoleName.values().length);
    }
}
