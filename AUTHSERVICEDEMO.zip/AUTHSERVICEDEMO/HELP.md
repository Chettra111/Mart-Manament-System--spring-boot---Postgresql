# Auth Service Demo

This project is a Maven Spring Boot Auth Service for a Mart Management System.

Main class:

`src/main/java/authservice/authservicedemo/AuthservicedemoApplication.java`

Start command on Windows:

```powershell
.\mvnw.cmd spring-boot:run
```
