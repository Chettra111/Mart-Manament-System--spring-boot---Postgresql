# AUTHSERVICEDEMO

A complete **Spring Boot Maven Auth Service** for the Mart Management System.

## Technology

- Java 21
- Spring Boot 4.1.0
- Maven
- Spring Web REST API
- Spring Data JPA
- Spring Security
- BCrypt password hashing
- JWT authentication with JJWT 0.13.0
- PostgreSQL

## Project structure

```text
AUTHSERVICEDEMO/
├── .mvn/wrapper/
├── database/
│   └── create_database.sql
├── src/
│   ├── main/
│   │   ├── java/authservice/authservicedemo/
│   │   │   ├── AuthservicedemoApplication.java
│   │   │   ├── config/
│   │   │   ├── controller/
│   │   │   ├── dto/
│   │   │   ├── entity/
│   │   │   ├── exception/
│   │   │   ├── repository/
│   │   │   ├── security/
│   │   │   └── service/
│   │   └── resources/
│   │       ├── application.properties
│   │       └── schema.sql
│   └── test/
├── mvnw
├── mvnw.cmd
├── pom.xml
└── postman-auth-service.json
```

## Database setup

Run this once in pgAdmin:

```sql
CREATE DATABASE mart_management_db;
```

The application uses the same database as the other mart services, but keeps its tables in the `auth` schema:

```text
auth.roles
auth.app_users
```

Default PostgreSQL configuration:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/mart_management_db
spring.datasource.username=postgres
spring.datasource.password=postgres
```

Change the password in `src/main/resources/application.properties` when your PostgreSQL password is different.

## Run on Windows

Open a terminal in the project folder containing `pom.xml`:

```powershell
.\mvnw.cmd spring-boot:run
```

Do not compile the Spring Boot main class with `javac`.

The service starts on:

```text
http://localhost:8081
```

## Default administrator

```text
Username: admin
Password: Admin@123
Role: ADMIN
```

## Roles

```text
ADMIN
MANAGER
CASHIER
STOCK_KEEPER
```

## Endpoints

| Method | Endpoint | Access |
|---|---|---|
| POST | `/api/auth/register` | Public; creates a CASHIER account |
| POST | `/api/auth/login` | Public |
| GET | `/api/auth/me` | Logged-in user |
| GET | `/api/users` | ADMIN |
| GET | `/api/users/{id}` | ADMIN |
| POST | `/api/users` | ADMIN |
| PUT | `/api/users/{id}` | ADMIN |
| DELETE | `/api/users/{id}` | ADMIN |
| GET | `/api/roles` | ADMIN |

## Login request

```http
POST http://localhost:8081/api/auth/login
Content-Type: application/json
```

```json
{
  "username": "admin",
  "password": "Admin@123"
}
```

Copy `accessToken` from the response. For protected endpoints add:

```text
Authorization: Bearer YOUR_ACCESS_TOKEN
```

A ready-to-import Postman collection is included in `postman-auth-service.json`.
