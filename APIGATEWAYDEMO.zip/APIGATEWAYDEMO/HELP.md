# APIGATEWAYDEMO

Run the project:

```powershell
.\mvnw.cmd spring-boot:run
```

Gateway:

```text
http://localhost:8080
```
