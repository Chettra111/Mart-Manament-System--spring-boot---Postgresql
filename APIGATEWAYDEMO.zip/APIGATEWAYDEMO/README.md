# Mart Management System - API Gateway

## Ports
- API Gateway: 8080
- Auth Service: 8081
- Operation Service: 8082
- Reporting Service: 8083
- CRON Service: 8084

## Flow
Frontend -> API Gateway -> Microservices

Use only port 8080 from the frontend.

Examples:
- POST http://localhost:8080/api/auth/login
- GET http://localhost:8080/api/categories
- GET http://localhost:8080/api/reports/dashboard
- GET http://localhost:8080/api/cron/jobs

## Public endpoints
- /api/auth/login
- /api/auth/register
- /api/auth/validate
- /api/gateway/status
- /actuator/health

## Protected endpoints
All other routed endpoints require:

Authorization: Bearer YOUR_JWT_TOKEN

The API Gateway validates the JWT and forwards the original Authorization header
to the downstream service.

## Start order
1. Auth Service
2. Operation Service
3. Reporting Service
4. CRON Service
5. API Gateway

## Run
```powershell
.\mvnw.cmd clean
.\mvnw.cmd spring-boot:run
```
