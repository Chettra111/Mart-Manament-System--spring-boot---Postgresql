package apigateway.apigatewaydemo.security;

import io.jsonwebtoken.JwtException;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Set;

@Component
public class JwtAuthenticationFilter implements GlobalFilter, Ordered {

    private static final Set<String> PUBLIC_PATHS = Set.of(
            "/api/auth/login",
            "/api/auth/register",
            "/api/auth/validate",
            "/api/gateway/status",
            "/actuator/health",
            "/actuator/info"
    );

    private final JwtService jwtService;

    public JwtAuthenticationFilter(JwtService jwtService) {
        this.jwtService = jwtService;
    }

    @Override
    public Mono<Void> filter(
            ServerWebExchange exchange,
            GatewayFilterChain chain
    ) {
        String path = exchange.getRequest().getURI().getPath();

        if (exchange.getRequest().getMethod() == HttpMethod.OPTIONS
                || PUBLIC_PATHS.contains(path)) {
            return chain.filter(exchange);
        }

        String authorizationHeader =
                exchange.getRequest()
                        .getHeaders()
                        .getFirst(HttpHeaders.AUTHORIZATION);

        if (authorizationHeader == null
                || !authorizationHeader.startsWith("Bearer ")) {
            return unauthorized(
                    exchange,
                    "Bearer token is required"
            );
        }

        String token = authorizationHeader.substring(7);

        try {
            if (!jwtService.isTokenValid(token)) {
                return unauthorized(
                        exchange,
                        "JWT token is invalid or expired"
                );
            }

            String username = jwtService.extractUsername(token);
            String role = jwtService.extractRole(token);

            ServerWebExchange authenticatedExchange =
                    exchange.mutate()
                            .request(request -> request
                                    .header(
                                            "X-Authenticated-User",
                                            username
                                    )
                                    .header(
                                            "X-Authenticated-Role",
                                            role
                                    )
                            )
                            .build();

            return chain.filter(authenticatedExchange);

        } catch (JwtException | IllegalArgumentException exception) {
            return unauthorized(
                    exchange,
                    "JWT token is invalid or expired"
            );
        }
    }

    private Mono<Void> unauthorized(
            ServerWebExchange exchange,
            String message
    ) {
        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        exchange.getResponse()
                .getHeaders()
                .setContentType(MediaType.APPLICATION_JSON);

        String body = String.format(
                "{\n" +
                "  \"timestamp\": \"%s\",\n" +
                "  \"status\": 401,\n" +
                "  \"error\": \"Unauthorized\",\n" +
                "  \"message\": \"%s\",\n" +
                "  \"path\": \"%s\"\n" +
                "}",
                Instant.now(),
                message,
                exchange.getRequest().getURI().getPath()
        );

        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);

        DataBuffer buffer =
                exchange.getResponse()
                        .bufferFactory()
                        .wrap(bytes);

        return exchange.getResponse()
                .writeWith(Mono.just(buffer));
    }

    @Override
    public int getOrder() {
        return -100;
    }
}
