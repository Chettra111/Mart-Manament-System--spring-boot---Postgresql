package apigateway.apigatewaydemo.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayRouteConfig {

    @Bean
    public RouteLocator martManagementRoutes(
            RouteLocatorBuilder builder,
            @Value("${app.services.auth-url}") String authUrl,
            @Value("${app.services.operation-url}") String operationUrl,
            @Value("${app.services.reporting-url}") String reportingUrl,
            @Value("${app.services.cron-url}") String cronUrl
    ) {

        return builder.routes()

                // =========================
                // AUTH SERVICE :8081
                // =========================
                .route("auth-service", route -> route
                        .path(
                                "/api/auth/**",
                                "/api/users/**",
                                "/api/roles/**"
                        )
                        .filters(filter -> filter
                                .removeRequestHeader("Origin")
                        )
                        .uri(authUrl)
                )

                // =========================
                // OPERATION SERVICE :8082
                // =========================
                .route("operation-service", route -> route
                        .path(
                                "/api/categories/**",
                                "/api/products/**",
                                "/api/suppliers/**",
                                "/api/customers/**",
                                "/api/employees/**",
                                "/api/purchases/**",
                                "/api/sales/**",
                                "/api/stock/**"
                        )
                        .filters(filter -> filter
                                .removeRequestHeader("Origin")
                        )
                        .uri(operationUrl)
                )

                // =========================
                // REPORTING SERVICE :8083
                // =========================
                .route("reporting-service", route -> route
                        .path(
                                "/api/reports/**",
                                "/api/report-runs/**"
                        )
                        .filters(filter -> filter
                                .removeRequestHeader("Origin")
                        )
                        .uri(reportingUrl)
                )

                // =========================
                // CRON SERVICE :8084
                // =========================
                .route("cron-service", route -> route
                        .path(
                                "/api/cron/**"
                        )
                        .filters(filter -> filter
                                .removeRequestHeader("Origin")
                        )
                        .uri(cronUrl)
                )

                .build();
    }
}