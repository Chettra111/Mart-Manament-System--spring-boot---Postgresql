package apigateway.apigatewaydemo.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/gateway")
public class GatewayStatusController {

    private final String authUrl;
    private final String operationUrl;
    private final String reportingUrl;
    private final String cronUrl;

    public GatewayStatusController(
            @Value("${app.services.auth-url}") String authUrl,
            @Value("${app.services.operation-url}") String operationUrl,
            @Value("${app.services.reporting-url}") String reportingUrl,
            @Value("${app.services.cron-url}") String cronUrl
    ) {
        this.authUrl = authUrl;
        this.operationUrl = operationUrl;
        this.reportingUrl = reportingUrl;
        this.cronUrl = cronUrl;
    }

    @GetMapping("/status")
    public Map<String, Object> status() {
        Map<String, Object> response = new LinkedHashMap<>();

        response.put("status", "UP");
        response.put("service", "API Gateway");
        response.put("timestamp", Instant.now());

        Map<String, String> routes = new LinkedHashMap<>();
        routes.put("auth", authUrl);
        routes.put("operation", operationUrl);
        routes.put("reporting", reportingUrl);
        routes.put("cron", cronUrl);

        response.put("routes", routes);

        return response;
    }
}
