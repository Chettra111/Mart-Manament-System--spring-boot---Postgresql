package operationservice.operationservicedemo.entity;

public enum EmployeePosition {
    MANAGER,
    CASHIER,
    STOCK_KEEPER,
    PURCHASING_STAFF,
    OTHER
}
