package operationservice.operationservicedemo.entity;

public enum TransactionStatus {
    COMPLETED,
    CANCELLED
}
