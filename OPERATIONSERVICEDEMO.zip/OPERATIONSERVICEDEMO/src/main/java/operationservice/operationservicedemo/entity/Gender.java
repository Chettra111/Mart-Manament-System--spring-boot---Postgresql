package operationservice.operationservicedemo.entity;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
