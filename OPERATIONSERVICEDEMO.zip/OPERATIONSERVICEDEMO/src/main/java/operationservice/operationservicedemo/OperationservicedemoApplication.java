package operationservice.operationservicedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OperationservicedemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(OperationservicedemoApplication.class, args);
    }
}
