// package operationservice.operationservicedemo.repository;

// import operationservice.operationservicedemo.entity.Sale;
// import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.data.jpa.repository.Query;
// import org.springframework.data.repository.query.Param;

// import java.time.LocalDateTime;
// import java.util.List;
// import java.util.Optional;

// public interface SaleRepository extends JpaRepository<Sale, Long> {
//     List<Sale> findAllByOrderBySaleDateDescIdDesc();
//     Optional<Sale> findByInvoiceNumberIgnoreCase(String invoiceNumber);

//     @Query("""
//             select s from Sale s
//             left join s.customer c
//             where (:invoiceNumber is null or lower(s.invoiceNumber) like lower(concat('%', :invoiceNumber, '%')))
//               and (:customerName is null or lower(c.name) like lower(concat('%', :customerName, '%')))
//               and (:fromDate is null or s.saleDate >= :fromDate)
//               and (:toDate is null or s.saleDate <= :toDate)
//             order by s.saleDate desc, s.id desc
//             """)
//     List<Sale> search(
//             @Param("invoiceNumber") String invoiceNumber,
//             @Param("customerName") String customerName,
//             @Param("fromDate") LocalDateTime fromDate,
//             @Param("toDate") LocalDateTime toDate
//     );
// }
package operationservice.operationservicedemo.repository;

import operationservice.operationservicedemo.entity.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface SaleRepository
        extends JpaRepository<Sale, Long>,
                JpaSpecificationExecutor<Sale> {

    List<Sale> findAllByOrderBySaleDateDescIdDesc();

    Optional<Sale> findByInvoiceNumberIgnoreCase(String invoiceNumber);
}