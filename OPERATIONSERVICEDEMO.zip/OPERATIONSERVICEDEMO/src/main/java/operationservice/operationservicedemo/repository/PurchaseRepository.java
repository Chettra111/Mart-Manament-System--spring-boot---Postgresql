package operationservice.operationservicedemo.repository;

import operationservice.operationservicedemo.entity.Purchase;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PurchaseRepository extends JpaRepository<Purchase, Long> {
    List<Purchase> findAllByOrderByPurchaseDateDescIdDesc();
    Optional<Purchase> findByPurchaseNumberIgnoreCase(String purchaseNumber);
}
