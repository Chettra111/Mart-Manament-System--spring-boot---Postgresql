package operationservice.operationservicedemo.repository;

import operationservice.operationservicedemo.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    Optional<Employee> findByCodeIgnoreCase(String code);
    boolean existsByCodeIgnoreCase(String code);
    boolean existsByAppUserId(Long appUserId);
    Optional<Employee> findByAppUserId(Long appUserId);
}
