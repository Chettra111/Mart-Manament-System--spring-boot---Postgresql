package operationservice.operationservicedemo.repository;

import jakarta.persistence.LockModeType;
import operationservice.operationservicedemo.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long> {
    Optional<Product> findByBarcodeIgnoreCase(String barcode);
    boolean existsByBarcodeIgnoreCase(String barcode);
    boolean existsByCategoryId(Long categoryId);
    List<Product> findByNameContainingIgnoreCaseOrBarcodeContainingIgnoreCaseOrderByNameAsc(String name, String barcode);

    @Query("select p from Product p where p.stockQuantity <= p.minimumStock order by p.stockQuantity asc")
    List<Product> findLowStockProducts();

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from Product p where p.id = :id")
    Optional<Product> findByIdForUpdate(@Param("id") Long id);
}
