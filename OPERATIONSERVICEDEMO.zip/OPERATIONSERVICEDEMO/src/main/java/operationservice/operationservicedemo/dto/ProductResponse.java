package operationservice.operationservicedemo.dto;

import java.math.BigDecimal;
import java.time.Instant;

public record ProductResponse(
        Long id,
        String barcode,
        String name,
        BigDecimal purchasePrice,
        BigDecimal sellingPrice,
        Integer stockQuantity,
        Integer minimumStock,
        boolean lowStock,
        boolean active,
        Long categoryId,
        String categoryName,
        Instant createdAt,
        Instant updatedAt
) {}
