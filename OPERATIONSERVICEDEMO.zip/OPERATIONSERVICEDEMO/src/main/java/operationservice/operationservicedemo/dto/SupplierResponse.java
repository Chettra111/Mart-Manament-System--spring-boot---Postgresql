package operationservice.operationservicedemo.dto;

import java.time.Instant;

public record SupplierResponse(
        Long id,
        String code,
        String name,
        String phone,
        String email,
        String address,
        boolean active,
        Instant createdAt,
        Instant updatedAt
) {}
