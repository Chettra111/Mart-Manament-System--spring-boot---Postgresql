package operationservice.operationservicedemo.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record PurchaseRequest(
        @NotNull Long supplierId,
        @NotNull Long employeeId,
        LocalDateTime purchaseDate,
        @PositiveOrZero BigDecimal discount,
        @PositiveOrZero BigDecimal tax,
        @Size(max = 1000) String notes,
        @NotEmpty List<@Valid PurchaseItemRequest> items
) {}
