package operationservice.operationservicedemo.dto;

import operationservice.operationservicedemo.entity.TransactionStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;

public record PurchaseResponse(
        Long id,
        String purchaseNumber,
        LocalDateTime purchaseDate,
        Long supplierId,
        String supplierName,
        Long employeeId,
        String employeeName,
        TransactionStatus status,
        BigDecimal subtotal,
        BigDecimal discount,
        BigDecimal tax,
        BigDecimal total,
        String notes,
        List<PurchaseItemResponse> items,
        Instant createdAt
) {}
