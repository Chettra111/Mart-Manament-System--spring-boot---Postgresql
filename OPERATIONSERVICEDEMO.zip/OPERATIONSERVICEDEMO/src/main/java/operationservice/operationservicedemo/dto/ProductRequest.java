package operationservice.operationservicedemo.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record ProductRequest(
        @NotBlank @Size(max = 100) String barcode,
        @NotBlank @Size(max = 150) String name,
        @NotNull @PositiveOrZero BigDecimal purchasePrice,
        @NotNull @Positive BigDecimal sellingPrice,
        @NotNull @PositiveOrZero Integer stockQuantity,
        @NotNull @PositiveOrZero Integer minimumStock,
        @NotNull Long categoryId,
        Boolean active
) {}
