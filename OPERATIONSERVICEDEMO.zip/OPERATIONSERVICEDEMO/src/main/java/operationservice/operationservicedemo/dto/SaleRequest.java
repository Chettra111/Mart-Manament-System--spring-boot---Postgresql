package operationservice.operationservicedemo.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record SaleRequest(
        Long customerId,
        @NotNull Long employeeId,
        LocalDateTime saleDate,
        @PositiveOrZero BigDecimal discount,
        @PositiveOrZero BigDecimal tax,
        @NotNull @PositiveOrZero BigDecimal amountPaid,
        @Size(max = 1000) String notes,
        @NotEmpty List<@Valid SaleItemRequest> items
) {}
