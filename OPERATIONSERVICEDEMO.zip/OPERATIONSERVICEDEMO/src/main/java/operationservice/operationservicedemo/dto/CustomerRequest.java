package operationservice.operationservicedemo.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CustomerRequest(
        @NotBlank @Size(max = 50) String code,
        @NotBlank @Size(max = 150) String name,
        @Size(max = 30) String phone,
        @Email @Size(max = 150) String email,
        @Size(max = 500) String address,
        Boolean active
) {}
