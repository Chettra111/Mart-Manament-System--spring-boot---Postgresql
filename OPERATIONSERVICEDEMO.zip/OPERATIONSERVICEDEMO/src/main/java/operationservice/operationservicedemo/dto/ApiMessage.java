package operationservice.operationservicedemo.dto;

public record ApiMessage(String message) {}
