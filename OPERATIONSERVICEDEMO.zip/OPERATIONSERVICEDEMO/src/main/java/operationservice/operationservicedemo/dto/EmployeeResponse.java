package operationservice.operationservicedemo.dto;

import operationservice.operationservicedemo.entity.EmployeePosition;
import operationservice.operationservicedemo.entity.EmployeeStatus;
import operationservice.operationservicedemo.entity.Gender;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

public record EmployeeResponse(
        Long id,
        String code,
        String firstName,
        String lastName,
        String fullName,
        Gender gender,
        String phone,
        String email,
        String address,
        EmployeePosition position,
        BigDecimal salary,
        LocalDate hireDate,
        EmployeeStatus status,
        Long appUserId,
        Instant createdAt,
        Instant updatedAt
) {}
