package operationservice.operationservicedemo.dto;

import java.time.Instant;

public record CustomerResponse(
        Long id,
        String code,
        String name,
        String phone,
        String email,
        String address,
        boolean active,
        Instant createdAt,
        Instant updatedAt
) {}
