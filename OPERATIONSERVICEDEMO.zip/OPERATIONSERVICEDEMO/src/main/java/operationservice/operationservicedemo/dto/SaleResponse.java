package operationservice.operationservicedemo.dto;

import operationservice.operationservicedemo.entity.TransactionStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;

public record SaleResponse(
        Long id,
        String invoiceNumber,
        LocalDateTime saleDate,
        Long customerId,
        String customerName,
        Long employeeId,
        String employeeName,
        TransactionStatus status,
        BigDecimal subtotal,
        BigDecimal discount,
        BigDecimal tax,
        BigDecimal total,
        BigDecimal amountPaid,
        BigDecimal changeAmount,
        String notes,
        List<SaleItemResponse> items,
        Instant createdAt
) {}
