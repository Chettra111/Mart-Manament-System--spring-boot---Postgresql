package operationservice.operationservicedemo.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import operationservice.operationservicedemo.entity.EmployeePosition;
import operationservice.operationservicedemo.entity.EmployeeStatus;
import operationservice.operationservicedemo.entity.Gender;

import java.math.BigDecimal;
import java.time.LocalDate;

public record EmployeeRequest(
        @NotBlank @Size(max = 50) String code,
        @NotBlank @Size(max = 100) String firstName,
        @NotBlank @Size(max = 100) String lastName,
        Gender gender,
        @Size(max = 30) String phone,
        @Email @Size(max = 150) String email,
        @Size(max = 500) String address,
        @NotNull EmployeePosition position,
        @NotNull @PositiveOrZero BigDecimal salary,
        @NotNull LocalDate hireDate,
        @NotNull EmployeeStatus status,
        Long appUserId
) {}
