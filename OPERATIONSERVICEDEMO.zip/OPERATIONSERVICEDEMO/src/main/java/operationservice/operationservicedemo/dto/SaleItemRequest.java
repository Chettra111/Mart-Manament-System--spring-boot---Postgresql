package operationservice.operationservicedemo.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;

public record SaleItemRequest(
        @NotNull Long productId,
        @NotNull @Positive Integer quantity,
        @Positive BigDecimal unitPrice
) {}
