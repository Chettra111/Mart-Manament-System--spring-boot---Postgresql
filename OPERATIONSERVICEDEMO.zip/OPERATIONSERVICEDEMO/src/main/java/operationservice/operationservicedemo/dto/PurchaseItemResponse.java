package operationservice.operationservicedemo.dto;

import java.math.BigDecimal;

public record PurchaseItemResponse(
        Long id,
        Long productId,
        String barcode,
        String productName,
        Integer quantity,
        BigDecimal unitCost,
        BigDecimal lineTotal
) {}
