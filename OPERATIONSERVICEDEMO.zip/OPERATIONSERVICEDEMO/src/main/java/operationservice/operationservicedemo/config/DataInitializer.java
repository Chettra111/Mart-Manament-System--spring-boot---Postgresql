package operationservice.operationservicedemo.config;

import operationservice.operationservicedemo.entity.Category;
import operationservice.operationservicedemo.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final CategoryRepository categoryRepository;
    private final boolean enabled;

    public DataInitializer(
            CategoryRepository categoryRepository,
            @Value("${app.bootstrap-data.enabled:true}") boolean enabled
    ) {
        this.categoryRepository = categoryRepository;
        this.enabled = enabled;
    }

    @Override
    public void run(String... args) {
        if (enabled && !categoryRepository.existsByNameIgnoreCase("General")) {
            Category category = new Category();
            category.setName("General");
            category.setDescription("Default product category");
            category.setActive(true);
            categoryRepository.save(category);
        }
    }
}
