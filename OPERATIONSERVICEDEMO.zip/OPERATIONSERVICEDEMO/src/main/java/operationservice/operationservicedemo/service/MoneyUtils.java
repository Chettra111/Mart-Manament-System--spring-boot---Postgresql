package operationservice.operationservicedemo.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

final class MoneyUtils {

    private MoneyUtils() {}

    static BigDecimal amount(BigDecimal value) {
        return (value == null ? BigDecimal.ZERO : value).setScale(2, RoundingMode.HALF_UP);
    }
}
