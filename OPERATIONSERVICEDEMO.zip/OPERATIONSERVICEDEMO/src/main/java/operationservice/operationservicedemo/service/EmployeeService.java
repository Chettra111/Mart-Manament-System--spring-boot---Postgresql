package operationservice.operationservicedemo.service;

import operationservice.operationservicedemo.dto.EmployeeRequest;
import operationservice.operationservicedemo.dto.EmployeeResponse;
import operationservice.operationservicedemo.entity.Employee;
import operationservice.operationservicedemo.exception.ConflictException;
import operationservice.operationservicedemo.exception.ResourceNotFoundException;
import operationservice.operationservicedemo.repository.EmployeeRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public List<EmployeeResponse> findAll() {
        return employeeRepository.findAll(Sort.by("firstName").ascending()).stream().map(this::toResponse).toList();
    }

    public EmployeeResponse findById(Long id) {
        return toResponse(getEntity(id));
    }

    @Transactional
    public EmployeeResponse create(EmployeeRequest request) {
        validateUnique(null, request);
        Employee employee = new Employee();
        apply(employee, request);
        return toResponse(employeeRepository.save(employee));
    }

    @Transactional
    public EmployeeResponse update(Long id, EmployeeRequest request) {
        Employee employee = getEntity(id);
        validateUnique(id, request);
        apply(employee, request);
        return toResponse(employeeRepository.save(employee));
    }

    @Transactional
    public void delete(Long id) {
        employeeRepository.delete(getEntity(id));
    }

    public Employee getEntity(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
    }

    private void validateUnique(Long currentId, EmployeeRequest request) {
        employeeRepository.findByCodeIgnoreCase(request.code().trim())
                .filter(other -> currentId == null || !other.getId().equals(currentId))
                .ifPresent(other -> { throw new ConflictException("Employee code already exists"); });

        if (request.appUserId() != null) {
            employeeRepository.findByAppUserId(request.appUserId())
                    .filter(other -> currentId == null || !other.getId().equals(currentId))
                    .ifPresent(other -> { throw new ConflictException("AppUser is already linked to another employee"); });
        }
    }

    private void apply(Employee employee, EmployeeRequest request) {
        employee.setCode(request.code().trim());
        employee.setFirstName(request.firstName().trim());
        employee.setLastName(request.lastName().trim());
        employee.setGender(request.gender());
        employee.setPhone(request.phone());
        employee.setEmail(request.email());
        employee.setAddress(request.address());
        employee.setPosition(request.position());
        employee.setSalary(MoneyUtils.amount(request.salary()));
        employee.setHireDate(request.hireDate());
        employee.setStatus(request.status());
        employee.setAppUserId(request.appUserId());
    }

    private EmployeeResponse toResponse(Employee employee) {
        return new EmployeeResponse(
                employee.getId(), employee.getCode(), employee.getFirstName(), employee.getLastName(),
                employee.getFullName(), employee.getGender(), employee.getPhone(), employee.getEmail(),
                employee.getAddress(), employee.getPosition(), employee.getSalary(), employee.getHireDate(),
                employee.getStatus(), employee.getAppUserId(), employee.getCreatedAt(), employee.getUpdatedAt()
        );
    }
}
