package operationservice.operationservicedemo.service;

import operationservice.operationservicedemo.dto.SaleItemRequest;
import operationservice.operationservicedemo.dto.SaleItemResponse;
import operationservice.operationservicedemo.dto.SaleRequest;
import operationservice.operationservicedemo.dto.SaleResponse;
import operationservice.operationservicedemo.entity.Customer;
import operationservice.operationservicedemo.entity.Employee;
import operationservice.operationservicedemo.entity.EmployeeStatus;
import operationservice.operationservicedemo.entity.Product;
import operationservice.operationservicedemo.entity.Sale;
import operationservice.operationservicedemo.entity.SaleItem;
import operationservice.operationservicedemo.entity.TransactionStatus;
import operationservice.operationservicedemo.exception.BusinessException;
import operationservice.operationservicedemo.exception.ResourceNotFoundException;
import operationservice.operationservicedemo.repository.ProductRepository;
import operationservice.operationservicedemo.repository.SaleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.Locale;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Service
@Transactional(readOnly = true)
public class SaleService {

    private final SaleRepository saleRepository;
    private final ProductRepository productRepository;
    private final CustomerService customerService;
    private final EmployeeService employeeService;

    public SaleService(
            SaleRepository saleRepository,
            ProductRepository productRepository,
            CustomerService customerService,
            EmployeeService employeeService
    ) {
        this.saleRepository = saleRepository;
        this.productRepository = productRepository;
        this.customerService = customerService;
        this.employeeService = employeeService;
    }

    public List<SaleResponse> findAll() {
        return saleRepository.findAllByOrderBySaleDateDescIdDesc().stream().map(this::toResponse).toList();
    }

    public SaleResponse findById(Long id) {
        return toResponse(getEntity(id));
    }

    // public List<SaleResponse> search(
    //         String invoiceNumber,
    //         String customerName,
    //         LocalDate fromDate,
    //         LocalDate toDate
    // ) {
    //     String invoice = blankToNull(invoiceNumber);
    //     String customer = blankToNull(customerName);
    //     LocalDateTime from = fromDate == null ? null : fromDate.atStartOfDay();
    //     LocalDateTime to = toDate == null ? null : toDate.atTime(LocalTime.MAX);
    //     return saleRepository.search(invoice, customer, from, to).stream().map(this::toResponse).toList();
    // }
    public List<SaleResponse> search(
            String invoiceNumber,
            String customerName,
            LocalDate fromDate,
            LocalDate toDate
    ) {
        String invoice = blankToNull(invoiceNumber);
        String customer = blankToNull(customerName);

        LocalDateTime from = fromDate == null
                ? null
                : fromDate.atStartOfDay();

        LocalDateTime to = toDate == null
                ? null
                : toDate.atTime(LocalTime.MAX);

        Specification<Sale> specification = (root, query, criteriaBuilder) -> {

            List<Predicate> predicates = new ArrayList<>();

            if (invoice != null) {
                predicates.add(
                        criteriaBuilder.like(
                                criteriaBuilder.lower(root.get("invoiceNumber")),
                                "%" + invoice.toLowerCase(Locale.ROOT) + "%"
                        )
                );
            }

            if (customer != null) {
                predicates.add(
                        criteriaBuilder.like(
                                criteriaBuilder.lower(
                                        root.join("customer", JoinType.LEFT).get("name")
                                ),
                                "%" + customer.toLowerCase(Locale.ROOT) + "%"
                        )
                );
            }

            if (from != null) {
                predicates.add(
                        criteriaBuilder.greaterThanOrEqualTo(
                                root.get("saleDate"),
                                from
                        )
                );
            }

            if (to != null) {
                predicates.add(
                        criteriaBuilder.lessThanOrEqualTo(
                                root.get("saleDate"),
                                to
                        )
                );
            }

            return criteriaBuilder.and(
                    predicates.toArray(new Predicate[0])
            );
        };

        Sort sort = Sort.by(
                Sort.Order.desc("saleDate"),
                Sort.Order.desc("id")
        );

        return saleRepository.findAll(specification, sort)
                .stream()
                .map(this::toResponse)
                .toList();
    }
    @Transactional
    public SaleResponse create(SaleRequest request) {
        Employee employee = employeeService.getEntity(request.employeeId());
        if (employee.getStatus() != EmployeeStatus.ACTIVE) {
            throw new BusinessException("Employee is not active");
        }

        Customer customer = null;
        if (request.customerId() != null) {
            customer = customerService.getEntity(request.customerId());
            if (!customer.isActive()) {
                throw new BusinessException("Customer is inactive");
            }
        }

        Sale sale = new Sale();
        sale.setInvoiceNumber(generateNumber());
        sale.setSaleDate(request.saleDate() == null ? LocalDateTime.now() : request.saleDate());
        sale.setCustomer(customer);
        sale.setEmployee(employee);
        sale.setStatus(TransactionStatus.COMPLETED);
        sale.setDiscount(MoneyUtils.amount(request.discount()));
        sale.setTax(MoneyUtils.amount(request.tax()));
        sale.setAmountPaid(MoneyUtils.amount(request.amountPaid()));
        sale.setNotes(request.notes());

        BigDecimal subtotal = BigDecimal.ZERO;
        for (SaleItemRequest itemRequest : request.items()) {
            Product product = productRepository.findByIdForUpdate(itemRequest.productId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Product not found with id: " + itemRequest.productId()));

            if (!product.isActive()) {
                throw new BusinessException("Product is inactive: " + product.getName());
            }
            if (product.getStockQuantity() < itemRequest.quantity()) {
                throw new BusinessException(
                        "Insufficient stock for " + product.getName()
                                + ". Available: " + product.getStockQuantity());
            }

            BigDecimal unitPrice = itemRequest.unitPrice() == null
                    ? product.getSellingPrice()
                    : MoneyUtils.amount(itemRequest.unitPrice());
            BigDecimal lineTotal = MoneyUtils.amount(unitPrice.multiply(BigDecimal.valueOf(itemRequest.quantity())));

            SaleItem item = new SaleItem();
            item.setProduct(product);
            item.setQuantity(itemRequest.quantity());
            item.setUnitPrice(unitPrice);
            item.setLineTotal(lineTotal);
            sale.addItem(item);

            product.setStockQuantity(product.getStockQuantity() - itemRequest.quantity());
            subtotal = subtotal.add(lineTotal);
        }

        subtotal = MoneyUtils.amount(subtotal);
        BigDecimal total = MoneyUtils.amount(subtotal.subtract(sale.getDiscount()).add(sale.getTax()));
        if (total.signum() < 0) {
            throw new BusinessException("Sale total cannot be negative");
        }
        if (sale.getAmountPaid().compareTo(total) < 0) {
            throw new BusinessException("Amount paid is less than sale total: " + total);
        }

        sale.setSubtotal(subtotal);
        sale.setTotal(total);
        sale.setChangeAmount(MoneyUtils.amount(sale.getAmountPaid().subtract(total)));
        return toResponse(saleRepository.save(sale));
    }

    @Transactional
    public SaleResponse cancel(Long id) {
        Sale sale = getEntity(id);
        if (sale.getStatus() == TransactionStatus.CANCELLED) {
            throw new BusinessException("Sale is already cancelled");
        }

        for (SaleItem item : sale.getItems()) {
            Product product = productRepository.findByIdForUpdate(item.getProduct().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product not found"));
            product.setStockQuantity(product.getStockQuantity() + item.getQuantity());
        }

        sale.setStatus(TransactionStatus.CANCELLED);
        return toResponse(saleRepository.save(sale));
    }

    @Transactional
    public void delete(Long id) {
        Sale sale = getEntity(id);
        if (sale.getStatus() != TransactionStatus.CANCELLED) {
            throw new BusinessException("Cancel the sale before deleting it");
        }
        saleRepository.delete(sale);
    }

    private Sale getEntity(Long id) {
        return saleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Sale not found with id: " + id));
    }

    private String generateNumber() {
        return "SAL-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"))
                + "-" + UUID.randomUUID().toString().substring(0, 4).toUpperCase();
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private SaleResponse toResponse(Sale sale) {
        List<SaleItemResponse> items = sale.getItems().stream()
                .map(item -> new SaleItemResponse(
                        item.getId(), item.getProduct().getId(), item.getProduct().getBarcode(),
                        item.getProduct().getName(), item.getQuantity(), item.getUnitPrice(), item.getLineTotal()))
                .toList();

        return new SaleResponse(
                sale.getId(), sale.getInvoiceNumber(), sale.getSaleDate(),
                sale.getCustomer() == null ? null : sale.getCustomer().getId(),
                sale.getCustomer() == null ? "Walk-in Customer" : sale.getCustomer().getName(),
                sale.getEmployee().getId(), sale.getEmployee().getFullName(), sale.getStatus(),
                sale.getSubtotal(), sale.getDiscount(), sale.getTax(), sale.getTotal(),
                sale.getAmountPaid(), sale.getChangeAmount(), sale.getNotes(), items, sale.getCreatedAt()
        );
    }
}
