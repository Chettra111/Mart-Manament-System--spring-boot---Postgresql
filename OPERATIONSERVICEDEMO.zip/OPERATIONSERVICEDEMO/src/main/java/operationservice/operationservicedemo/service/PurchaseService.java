package operationservice.operationservicedemo.service;

import operationservice.operationservicedemo.dto.PurchaseItemRequest;
import operationservice.operationservicedemo.dto.PurchaseItemResponse;
import operationservice.operationservicedemo.dto.PurchaseRequest;
import operationservice.operationservicedemo.dto.PurchaseResponse;
import operationservice.operationservicedemo.entity.Employee;
import operationservice.operationservicedemo.entity.EmployeeStatus;
import operationservice.operationservicedemo.entity.Product;
import operationservice.operationservicedemo.entity.Purchase;
import operationservice.operationservicedemo.entity.PurchaseItem;
import operationservice.operationservicedemo.entity.Supplier;
import operationservice.operationservicedemo.entity.TransactionStatus;
import operationservice.operationservicedemo.exception.BusinessException;
import operationservice.operationservicedemo.exception.ResourceNotFoundException;
import operationservice.operationservicedemo.repository.ProductRepository;
import operationservice.operationservicedemo.repository.PurchaseRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Service
@Transactional(readOnly = true)
public class PurchaseService {

    private final PurchaseRepository purchaseRepository;
    private final ProductRepository productRepository;
    private final SupplierService supplierService;
    private final EmployeeService employeeService;

    public PurchaseService(
            PurchaseRepository purchaseRepository,
            ProductRepository productRepository,
            SupplierService supplierService,
            EmployeeService employeeService
    ) {
        this.purchaseRepository = purchaseRepository;
        this.productRepository = productRepository;
        this.supplierService = supplierService;
        this.employeeService = employeeService;
    }

    public List<PurchaseResponse> findAll() {
        return purchaseRepository.findAllByOrderByPurchaseDateDescIdDesc().stream()
                .map(this::toResponse)
                .toList();
    }

    public PurchaseResponse findById(Long id) {
        return toResponse(getEntity(id));
    }

    @Transactional
    public PurchaseResponse create(PurchaseRequest request) {
        Supplier supplier = supplierService.getEntity(request.supplierId());
        Employee employee = employeeService.getEntity(request.employeeId());

        if (!supplier.isActive()) {
            throw new BusinessException("Supplier is inactive");
        }
        if (employee.getStatus() != EmployeeStatus.ACTIVE) {
            throw new BusinessException("Employee is not active");
        }

        Purchase purchase = new Purchase();
        purchase.setPurchaseNumber(generateNumber());
        purchase.setPurchaseDate(request.purchaseDate() == null ? LocalDateTime.now() : request.purchaseDate());
        purchase.setSupplier(supplier);
        purchase.setEmployee(employee);
        purchase.setStatus(TransactionStatus.COMPLETED);
        purchase.setDiscount(MoneyUtils.amount(request.discount()));
        purchase.setTax(MoneyUtils.amount(request.tax()));
        purchase.setNotes(request.notes());

        BigDecimal subtotal = BigDecimal.ZERO;
        for (PurchaseItemRequest itemRequest : request.items()) {
            Product product = productRepository.findByIdForUpdate(itemRequest.productId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Product not found with id: " + itemRequest.productId()));

            BigDecimal unitCost = MoneyUtils.amount(itemRequest.unitCost());
            BigDecimal lineTotal = MoneyUtils.amount(unitCost.multiply(BigDecimal.valueOf(itemRequest.quantity())));

            PurchaseItem item = new PurchaseItem();
            item.setProduct(product);
            item.setQuantity(itemRequest.quantity());
            item.setUnitCost(unitCost);
            item.setLineTotal(lineTotal);
            purchase.addItem(item);

            product.setStockQuantity(product.getStockQuantity() + itemRequest.quantity());
            product.setPurchasePrice(unitCost);
            subtotal = subtotal.add(lineTotal);
        }

        subtotal = MoneyUtils.amount(subtotal);
        BigDecimal total = MoneyUtils.amount(subtotal.subtract(purchase.getDiscount()).add(purchase.getTax()));
        if (total.signum() < 0) {
            throw new BusinessException("Purchase total cannot be negative");
        }

        purchase.setSubtotal(subtotal);
        purchase.setTotal(total);
        return toResponse(purchaseRepository.save(purchase));
    }

    @Transactional
    public PurchaseResponse cancel(Long id) {
        Purchase purchase = getEntity(id);
        if (purchase.getStatus() == TransactionStatus.CANCELLED) {
            throw new BusinessException("Purchase is already cancelled");
        }

        for (PurchaseItem item : purchase.getItems()) {
            Product product = productRepository.findByIdForUpdate(item.getProduct().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product not found"));
            if (product.getStockQuantity() < item.getQuantity()) {
                throw new BusinessException(
                        "Cannot cancel purchase. Current stock of " + product.getName() + " is too low");
            }
            product.setStockQuantity(product.getStockQuantity() - item.getQuantity());
        }

        purchase.setStatus(TransactionStatus.CANCELLED);
        return toResponse(purchaseRepository.save(purchase));
    }

    @Transactional
    public void delete(Long id) {
        Purchase purchase = getEntity(id);
        if (purchase.getStatus() != TransactionStatus.CANCELLED) {
            throw new BusinessException("Cancel the purchase before deleting it");
        }
        purchaseRepository.delete(purchase);
    }

    private Purchase getEntity(Long id) {
        return purchaseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Purchase not found with id: " + id));
    }

    private String generateNumber() {
        return "PUR-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"))
                + "-" + UUID.randomUUID().toString().substring(0, 4).toUpperCase();
    }

    private PurchaseResponse toResponse(Purchase purchase) {
        List<PurchaseItemResponse> items = purchase.getItems().stream()
                .map(item -> new PurchaseItemResponse(
                        item.getId(), item.getProduct().getId(), item.getProduct().getBarcode(),
                        item.getProduct().getName(), item.getQuantity(), item.getUnitCost(), item.getLineTotal()))
                .toList();

        return new PurchaseResponse(
                purchase.getId(), purchase.getPurchaseNumber(), purchase.getPurchaseDate(),
                purchase.getSupplier().getId(), purchase.getSupplier().getName(),
                purchase.getEmployee().getId(), purchase.getEmployee().getFullName(),
                purchase.getStatus(), purchase.getSubtotal(), purchase.getDiscount(), purchase.getTax(),
                purchase.getTotal(), purchase.getNotes(), items, purchase.getCreatedAt()
        );
    }
}
