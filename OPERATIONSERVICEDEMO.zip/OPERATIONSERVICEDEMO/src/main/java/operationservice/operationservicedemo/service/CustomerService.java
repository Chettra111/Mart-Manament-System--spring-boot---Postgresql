package operationservice.operationservicedemo.service;

import operationservice.operationservicedemo.dto.CustomerRequest;
import operationservice.operationservicedemo.dto.CustomerResponse;
import operationservice.operationservicedemo.entity.Customer;
import operationservice.operationservicedemo.exception.ConflictException;
import operationservice.operationservicedemo.exception.ResourceNotFoundException;
import operationservice.operationservicedemo.repository.CustomerRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public List<CustomerResponse> findAll() {
        return customerRepository.findAll(Sort.by("name").ascending()).stream().map(this::toResponse).toList();
    }

    public CustomerResponse findById(Long id) {
        return toResponse(getEntity(id));
    }

    @Transactional
    public CustomerResponse create(CustomerRequest request) {
        if (customerRepository.existsByCodeIgnoreCase(request.code().trim())) {
            throw new ConflictException("Customer code already exists: " + request.code());
        }
        Customer customer = new Customer();
        apply(customer, request);
        return toResponse(customerRepository.save(customer));
    }

    @Transactional
    public CustomerResponse update(Long id, CustomerRequest request) {
        Customer customer = getEntity(id);
        customerRepository.findByCodeIgnoreCase(request.code().trim())
                .filter(other -> !other.getId().equals(id))
                .ifPresent(other -> { throw new ConflictException("Customer code already exists"); });
        apply(customer, request);
        return toResponse(customerRepository.save(customer));
    }

    @Transactional
    public void delete(Long id) {
        customerRepository.delete(getEntity(id));
    }

    public Customer getEntity(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + id));
    }

    private void apply(Customer customer, CustomerRequest request) {
        customer.setCode(request.code().trim());
        customer.setName(request.name().trim());
        customer.setPhone(request.phone());
        customer.setEmail(request.email());
        customer.setAddress(request.address());
        customer.setActive(request.active() == null || request.active());
    }

    private CustomerResponse toResponse(Customer customer) {
        return new CustomerResponse(
                customer.getId(), customer.getCode(), customer.getName(), customer.getPhone(),
                customer.getEmail(), customer.getAddress(), customer.isActive(),
                customer.getCreatedAt(), customer.getUpdatedAt()
        );
    }
}
