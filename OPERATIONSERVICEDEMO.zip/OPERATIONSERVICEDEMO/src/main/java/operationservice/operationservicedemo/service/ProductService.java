package operationservice.operationservicedemo.service;

import operationservice.operationservicedemo.dto.ProductRequest;
import operationservice.operationservicedemo.dto.ProductResponse;
import operationservice.operationservicedemo.dto.StockAdjustmentRequest;
import operationservice.operationservicedemo.entity.Category;
import operationservice.operationservicedemo.entity.Product;
import operationservice.operationservicedemo.exception.BusinessException;
import operationservice.operationservicedemo.exception.ConflictException;
import operationservice.operationservicedemo.exception.ResourceNotFoundException;
import operationservice.operationservicedemo.repository.ProductRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class ProductService {

    private final ProductRepository productRepository;
    private final CategoryService categoryService;

    public ProductService(ProductRepository productRepository, CategoryService categoryService) {
        this.productRepository = productRepository;
        this.categoryService = categoryService;
    }

    public List<ProductResponse> findAll(String keyword) {
        List<Product> products = keyword == null || keyword.isBlank()
                ? productRepository.findAll(Sort.by("name").ascending())
                : productRepository.findByNameContainingIgnoreCaseOrBarcodeContainingIgnoreCaseOrderByNameAsc(
                        keyword.trim(), keyword.trim());
        return products.stream().map(this::toResponse).toList();
    }

    public List<ProductResponse> findLowStock() {
        return productRepository.findLowStockProducts().stream().map(this::toResponse).toList();
    }

    public ProductResponse findById(Long id) {
        return toResponse(getEntity(id));
    }

    @Transactional
    public ProductResponse create(ProductRequest request) {
        String barcode = request.barcode().trim();
        if (productRepository.existsByBarcodeIgnoreCase(barcode)) {
            throw new ConflictException("Product barcode already exists: " + barcode);
        }
        Product product = new Product();
        apply(product, request);
        return toResponse(productRepository.save(product));
    }

    @Transactional
    public ProductResponse update(Long id, ProductRequest request) {
        Product product = getEntity(id);
        productRepository.findByBarcodeIgnoreCase(request.barcode().trim())
                .filter(other -> !other.getId().equals(id))
                .ifPresent(other -> { throw new ConflictException("Product barcode already exists"); });
        apply(product, request);
        return toResponse(productRepository.save(product));
    }

    @Transactional
    public ProductResponse adjustStock(Long id, StockAdjustmentRequest request) {
        Product product = productRepository.findByIdForUpdate(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        int newQuantity = product.getStockQuantity() + request.quantityChange();
        if (newQuantity < 0) {
            throw new BusinessException("Stock cannot be negative. Current stock: " + product.getStockQuantity());
        }
        product.setStockQuantity(newQuantity);
        return toResponse(productRepository.save(product));
    }

    @Transactional
    public void delete(Long id) {
        productRepository.delete(getEntity(id));
    }

    public Product getEntity(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
    }

    private void apply(Product product, ProductRequest request) {
        Category category = categoryService.getEntity(request.categoryId());
        product.setBarcode(request.barcode().trim());
        product.setName(request.name().trim());
        product.setPurchasePrice(MoneyUtils.amount(request.purchasePrice()));
        product.setSellingPrice(MoneyUtils.amount(request.sellingPrice()));
        product.setStockQuantity(request.stockQuantity());
        product.setMinimumStock(request.minimumStock());
        product.setCategory(category);
        product.setActive(request.active() == null || request.active());
    }

    public ProductResponse toResponse(Product product) {
        return new ProductResponse(
                product.getId(), product.getBarcode(), product.getName(), product.getPurchasePrice(),
                product.getSellingPrice(), product.getStockQuantity(), product.getMinimumStock(),
                product.getStockQuantity() <= product.getMinimumStock(), product.isActive(),
                product.getCategory().getId(), product.getCategory().getName(),
                product.getCreatedAt(), product.getUpdatedAt()
        );
    }
}
