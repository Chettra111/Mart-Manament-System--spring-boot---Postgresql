package operationservice.operationservicedemo.controller;

import jakarta.validation.Valid;
import operationservice.operationservicedemo.dto.ApiMessage;
import operationservice.operationservicedemo.dto.SaleRequest;
import operationservice.operationservicedemo.dto.SaleResponse;
import operationservice.operationservicedemo.service.SaleService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/sales")
@PreAuthorize("hasAnyRole('ADMIN','MANAGER','CASHIER')")
public class SaleController {

    private final SaleService saleService;

    public SaleController(SaleService saleService) {
        this.saleService = saleService;
    }

    @GetMapping
    public List<SaleResponse> findAll() { return saleService.findAll(); }

    @GetMapping("/{id}")
    public SaleResponse findById(@PathVariable Long id) { return saleService.findById(id); }

    @GetMapping("/search")
    public List<SaleResponse> search(
            @RequestParam(required = false) String invoiceNumber,
            @RequestParam(required = false) String customerName,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate
    ) {
        return saleService.search(invoiceNumber, customerName, fromDate, toDate);
    }

    @PostMapping
    public ResponseEntity<SaleResponse> create(@Valid @RequestBody SaleRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(saleService.create(request));
    }

    @PostMapping("/{id}/cancel")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public SaleResponse cancel(@PathVariable Long id) { return saleService.cancel(id); }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ApiMessage delete(@PathVariable Long id) {
        saleService.delete(id);
        return new ApiMessage("Sale deleted successfully");
    }
}
