package operationservice.operationservicedemo.controller;

import jakarta.validation.Valid;
import operationservice.operationservicedemo.dto.ApiMessage;
import operationservice.operationservicedemo.dto.PurchaseRequest;
import operationservice.operationservicedemo.dto.PurchaseResponse;
import operationservice.operationservicedemo.service.PurchaseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/purchases")
@PreAuthorize("hasAnyRole('ADMIN','MANAGER','STOCK_KEEPER')")
public class PurchaseController {

    private final PurchaseService purchaseService;

    public PurchaseController(PurchaseService purchaseService) {
        this.purchaseService = purchaseService;
    }

    @GetMapping
    public List<PurchaseResponse> findAll() { return purchaseService.findAll(); }

    @GetMapping("/{id}")
    public PurchaseResponse findById(@PathVariable Long id) { return purchaseService.findById(id); }

    @PostMapping
    public ResponseEntity<PurchaseResponse> create(@Valid @RequestBody PurchaseRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(purchaseService.create(request));
    }

    @PostMapping("/{id}/cancel")
    public PurchaseResponse cancel(@PathVariable Long id) { return purchaseService.cancel(id); }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ApiMessage delete(@PathVariable Long id) {
        purchaseService.delete(id);
        return new ApiMessage("Purchase deleted successfully");
    }
}
