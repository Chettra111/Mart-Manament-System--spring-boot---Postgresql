package operationservice.operationservicedemo;

import operationservice.operationservicedemo.entity.TransactionStatus;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class EnumTest {

    @Test
    void transactionStatusContainsCompleted() {
        assertEquals(TransactionStatus.COMPLETED, TransactionStatus.valueOf("COMPLETED"));
    }
}
