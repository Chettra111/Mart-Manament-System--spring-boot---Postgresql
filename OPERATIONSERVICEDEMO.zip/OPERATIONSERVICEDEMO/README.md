# Mart Management System - Operation Service

Spring Boot Maven microservice for the main mart operations. It follows the same package structure as `AUTHSERVICEDEMO`.

## Technology

- Java 21
- Spring Boot 4.1.0
- Maven
- Spring Web
- Spring Data JPA
- Spring Security
- JWT validation
- PostgreSQL

## Project structure

```text
OPERATIONSERVICEDEMO/
├── .mvn/
├── database/
├── src/main/java/operationservice/operationservicedemo/
│   ├── config/
│   ├── controller/
│   ├── dto/
│   ├── entity/
│   ├── exception/
│   ├── repository/
│   ├── security/
│   ├── service/
│   └── OperationservicedemoApplication.java
├── src/main/resources/
│   ├── application.properties
│   └── schema.sql
├── mvnw
├── mvnw.cmd
├── pom.xml
└── postman-operation-service.json
```

## Modules included

- Category CRUD
- Product CRUD and search
- Supplier CRUD
- Customer CRUD
- Employee CRUD
- Purchase transaction and cancellation
- Sale transaction, search, and cancellation
- Automatic stock increase after purchase
- Automatic stock decrease after sale
- Low-stock list
- Manual stock adjustment
- Role-based endpoint security

## Database

Both services use one PostgreSQL database:

```text
mart_management_db
```

Schemas:

```text
auth       -> Auth Service tables
operation  -> Operation Service tables
```

Create the database only once:

```sql
CREATE DATABASE mart_management_db;
```

The Operation Service automatically creates the `operation` schema and its tables.

## Configuration

Open:

```text
src/main/resources/application.properties
```

Default database settings:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/mart_management_db
spring.datasource.username=postgres
spring.datasource.password=postgres
```

Change the password to your PostgreSQL password.

The JWT secret in Operation Service must be exactly the same as Auth Service:

```properties
app.jwt.secret=Fv7/YT6BJviXt2U812YUCUPhcyA7MpFLfrmwAtBlJc4=
```

## Run services

First run Auth Service on port 8081:

```powershell
cd AUTHSERVICEDEMO
.\mvnw.cmd spring-boot:run
```

Then run Operation Service on port 8082:

```powershell
cd OPERATIONSERVICEDEMO
.\mvnw.cmd spring-boot:run
```

Do not run a Spring Boot file with `javac`.

## Authentication

Login through Auth Service:

```http
POST http://localhost:8081/api/auth/login
```

```json
{
  "username": "admin",
  "password": "Admin@123"
}
```

Copy `accessToken` and send it to Operation Service:

```text
Authorization: Bearer YOUR_ACCESS_TOKEN
```

## Main endpoints

| Module | Endpoints |
|---|---|
| Categories | `/api/categories` |
| Products | `/api/products` |
| Suppliers | `/api/suppliers` |
| Customers | `/api/customers` |
| Employees | `/api/employees` |
| Purchases | `/api/purchases` |
| Sales | `/api/sales` |
| Stock | `/api/stock` |
| Low stock | `/api/stock/low` |
| Sale search | `/api/sales/search` |

## Example creation order

Use this order because later records depend on earlier records:

```text
Category
  -> Product
  -> Supplier
  -> Customer
  -> Employee
  -> Purchase
  -> Sale
```

## Employee and AppUser

`Employee.appUserId` stores the ID of an account created by Auth Service. It is optional. Operation Service does not duplicate the Auth Service user table.

## Transaction rules

- A completed purchase increases product stock.
- Cancelling a purchase reverses its stock increase, but only when enough stock remains.
- A completed sale decreases product stock.
- A sale fails when stock is insufficient.
- Cancelling a sale returns its quantity to stock.
- A purchase or sale must be cancelled before deletion.

## Postman

Import:

```text
postman-operation-service.json
```

Run requests in order. The first request logs in to Auth Service and automatically saves the administrator token.
