-- Run only if the shared database does not exist yet.
CREATE DATABASE mart_management_db;

-- Auth Service uses schema: auth
-- Operation Service automatically creates schema: operation
