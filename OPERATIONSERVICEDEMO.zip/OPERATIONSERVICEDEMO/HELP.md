# Operation Service
Run from the folder containing `pom.xml`:

```powershell
.\mvnw.cmd spring-boot:run
```

Base URL: `http://localhost:8082`
